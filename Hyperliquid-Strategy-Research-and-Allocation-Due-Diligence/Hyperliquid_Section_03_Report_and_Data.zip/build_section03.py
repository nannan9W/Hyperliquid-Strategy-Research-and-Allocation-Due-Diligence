"""Reproduce Section 3 funding statistics and its publication figure.

Offline only. Reads the six frozen JSON inputs in ./inputs and writes ./outputs.
Dependencies: numpy, pandas, matplotlib.
"""

from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm, Normalize


ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"
OUTPUTS = ROOT / "outputs"
OUTPUTS.mkdir(exist_ok=True)
START = pd.Timestamp("2025-09-01", tz="UTC")
END = pd.Timestamp("2026-09-01", tz="UTC")
MONTHS = pd.period_range("2025-09", "2026-08", freq="M").astype(str).tolist()


def load(name):
    return json.loads((INPUTS / name).read_text())


def fund_data(asset):
    frame = pd.DataFrame(load(f"{asset.lower()}_funding_hourly.json")["rows"])
    frame["timestamp"] = pd.to_datetime(frame["time"], unit="ms", utc=True)
    frame = frame.loc[(frame.timestamp >= START) & (frame.timestamp < END)].sort_values("timestamp")
    frame["hour"] = frame.timestamp.dt.floor("h")
    frame["rate"] = pd.to_numeric(frame.fundingRate)
    expected = pd.date_range(START, END, freq="h", inclusive="left")
    if frame.hour.duplicated().any() or len(frame) != len(expected) or set(frame.hour) != set(expected):
        raise ValueError(f"{asset}: funding grid is incomplete or duplicated")
    if not np.isfinite(frame.rate).all():
        raise ValueError(f"{asset}: invalid rate")
    frame["month"] = frame.timestamp.dt.strftime("%Y-%m")
    return frame


def spells(frame):
    signs = np.sign(frame.rate.to_numpy()).astype(int)
    edges = np.r_[0, np.flatnonzero(signs[1:] != signs[:-1]) + 1, len(signs)]
    return [
        {
            "sign": int(signs[a]),
            "hours": int(b - a),
            "start_utc": frame.iloc[a].timestamp.isoformat(),
            "last_settlement_utc": frame.iloc[b - 1].timestamp.isoformat(),
            "left_boundary_censored": bool(a == 0),
            "right_boundary_censored": bool(b == len(signs)),
        }
        for a, b in zip(edges[:-1], edges[1:])
    ]


stats, monthly, volume, all_spells = {}, {}, {}, {}
for asset in ["BTC", "ETH"]:
    frame = fund_data(asset)
    rates = frame.rate.to_numpy()
    signs = np.sign(rates)
    runs = spells(frame)
    all_spells[asset] = runs
    negative = [x["hours"] for x in runs if x["sign"] == -1]
    positive = [x["hours"] for x in runs if x["sign"] == 1]
    q = np.quantile(rates * 10000, [.01, .05, .5, .95, .99])
    stats[asset] = {
        "hours": len(frame),
        "positive_hours": int((rates > 0).sum()),
        "negative_hours": int((rates < 0).sum()),
        "zero_hours": int((rates == 0).sum()),
        "positive_percent": float(100 * (rates > 0).mean()),
        "negative_percent": float(100 * (rates < 0).mean()),
        "mean_bps_per_hour": float(rates.mean() * 10000),
        "quantiles_bps_per_hour": dict(zip(["p01", "p05", "p50", "p95", "p99"], map(float, q))),
        "direct_positive_negative_switches": int(np.sum(signs[:-1] * signs[1:] == -1)),
        "negative_episodes": len(negative),
        "median_negative_episode_hours": float(np.median(negative)),
        "longest_observed_negative_episode_hours": int(max(negative)),
        "median_observed_positive_episode_hours": float(np.median(positive)),
        "negative_boundary_censored_episodes": sum(
            x["sign"] == -1 and (x["left_boundary_censored"] or x["right_boundary_censored"])
            for x in runs
        ),
    }
    monthly[asset] = []
    for month in MONTHS:
        m = frame.loc[frame.month == month, "rate"]
        monthly[asset].append({
            "month": month,
            "observed_hours": len(m),
            "mean_bps_per_hour": float(m.mean() * 10000),
            "positive_hours_percent": float(100 * (m > 0).mean()),
            "negative_hours_percent": float(100 * (m < 0).mean()),
        })
    totals = {}
    for leg in ["spot", "perp"]:
        bars = pd.DataFrame(load(f"{asset.lower()}_{leg}_daily.json")["response"])
        time = pd.to_datetime(bars.t, unit="ms", utc=True)
        bars = bars.loc[(time >= START) & (time < END)]
        totals[leg] = float(pd.to_numeric(bars.v).sum())
    volume[asset] = {
        "spot_volume_mapped_base_units": totals["spot"],
        "perpetual_volume_base_units": totals["perp"],
        "spot_to_perpetual_volume_percent": totals["spot"] / totals["perp"] * 100,
        "unit_note": "Nominal mapped base units; not USD volume and not platform market share.",
    }

btc_bars = pd.DataFrame(load("btc_perp_daily.json")["response"])
btc_bars["date"] = pd.to_datetime(btc_bars.t, unit="ms", utc=True)
btc_bars = btc_bars.loc[(btc_bars.date >= START) & (btc_bars.date < END)].copy()
btc_bars["log_high_low"] = np.log(pd.to_numeric(btc_bars.h) / pd.to_numeric(btc_bars.l))
thresholds = btc_bars.log_high_low.quantile([.4, .6, .9])
btc_bars["regime"] = "outside_comparison"
btc_bars.loc[btc_bars.log_high_low.between(thresholds.loc[.4], thresholds.loc[.6]), "regime"] = "normal"
btc_bars.loc[btc_bars.log_high_low >= thresholds.loc[.9], "regime"] = "stress"
calendar = [
    {"date_utc": row.date.strftime("%Y-%m-%d"), "btc_log_high_low": float(row.log_high_low), "regime": row.regime}
    for row in btc_bars.itertuples()
]
regime_spec = {
    "reference": "BTC perpetual daily log(high/low), full observation window",
    "thresholds": {f"p{int(k * 100)}": float(v) for k, v in thresholds.items()},
    "counts": {str(k): int(v) for k, v in btc_bars.regime.value_counts().items()},
    "interpretation": "Ex-post price-range classification for descriptive liquidity comparison, not a live signal or an observed liquidity result.",
    "comparison_design": "Use common month/time-of-day strata, equal day weighting, and synchronized historical L2; report missing or unsupported strata.",
}

summary = {
    "window": {"start_utc_inclusive": START.isoformat(), "end_utc_exclusive": END.isoformat()},
    "source_observation_date": "2026-09-09",
    "calculation_date": "2026-09-10",
    "funding": stats,
    "monthly_funding": monthly,
    "reported_volume": volume,
    "proposed_liquidity_regimes": regime_spec,
    "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(INPUTS.glob("*.json"))},
    "limitations": [
        "Funding rates are not portfolio returns or funding cash PnL.",
        "The reported volume ratio is in mapped base units and is not a venue-wide concentration measure.",
        "Historical OI, full-universe concentration, fees and order-book distributions are not verified.",
        "No synthetic or current order-book observations are substituted for the missing historical records.",
    ],
}
(OUTPUTS / "section03_statistics.json").write_text(json.dumps(summary, indent=2))
(OUTPUTS / "funding_spells.json").write_text(json.dumps(all_spells, indent=2))
(OUTPUTS / "liquidity_regime_calendar.json").write_text(json.dumps(calendar, indent=2))

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11, "axes.titleweight": "bold", "svg.fonttype": "none"})
fig = plt.figure(figsize=(14.5, 6.5), facecolor="white")
ink = "#172F3B"
fig.text(.065, .94, "Hourly funding across BTC and ETH", fontsize=21, fontweight="bold", color=ink)
fig.text(.065, .888, "1 September 2025 – 31 August 2026  |  8,760 hourly settlements per asset", fontsize=11.5, color="#536670")
labels = ["Sep 25", "Oct", "Nov", "Dec", "Jan 26", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug"]
means = np.array([[r["mean_bps_per_hour"] for r in monthly[a]] for a in ["BTC", "ETH"]])
shares = np.array([[r["positive_hours_percent"] for r in monthly[a]] for a in ["BTC", "ETH"]])
diverging = LinearSegmentedColormap.from_list("funding_diverging", ["#B95E37", "#FAF8F2", "#087F8C"])
sequential = LinearSegmentedColormap.from_list("positive_share", ["#F4F7F7", "#8AC2C3", "#08666E"])

panels = [
    (means, .57, "A   Mean hourly funding rate (basis points)", diverging, TwoSlopeNorm(vmin=-.13, vcenter=0, vmax=.13), "bps/hour"),
    (shares, .235, "B   Hours with positive funding (%)", sequential, Normalize(vmin=0, vmax=100), "% of hours"),
]
for index, (values, bottom, title, cmap, norm, unit) in enumerate(panels):
    ax = fig.add_axes([.095, bottom, .76, .215])
    im = ax.imshow(values, aspect="auto", cmap=cmap, norm=norm)
    ax.set_title(title, loc="left", fontsize=12.5, pad=12, color=ink)
    ax.set_xticks(np.arange(12), labels, fontsize=10.5, color=ink)
    ax.set_yticks([0, 1], ["BTC", "ETH"], fontsize=12.5, color=ink)
    ax.tick_params(axis="both", which="both", length=0, pad=9)
    ax.set_xticks(np.arange(-.5, 12, 1), minor=True)
    ax.set_yticks(np.arange(-.5, 2, 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=2)
    for spine in ax.spines.values():
        spine.set_visible(False)
    for row in range(2):
        for column in range(12):
            value = values[row, column]
            rgba = cmap(norm(value))
            luminance = .2126 * rgba[0] + .7152 * rgba[1] + .0722 * rgba[2]
            label = f"{value:.3f}" if index == 0 else f"{value:.1f}%"
            ax.text(column, row, label, ha="center", va="center", fontsize=11, color="white" if luminance < .52 else ink, fontweight="medium")
    cax = fig.add_axes([.887, bottom, .013, .215])
    bar = fig.colorbar(im, cax=cax)
    bar.outline.set_visible(False)
    bar.ax.tick_params(labelsize=9, length=0)
    bar.set_label(unit, fontsize=9.5, labelpad=8, color=ink)
    if index == 0:
        bar.set_ticks([-.125, 0, .125])
    else:
        bar.set_ticks([0, 50, 100])

fig.text(.065, .115, "Positive funding pays shorts; negative funding pays longs. Monthly averages use the actual hourly observations.", fontsize=10.3, color="#536670")
fig.text(.065, .079, "Source: Hyperliquid Info API; author calculations. Rates exclude trading costs and do not measure strategy returns.", fontsize=10.3, color="#536670")
fig.savefig(OUTPUTS / "Hyperliquid_Funding_Heatmap.png", dpi=240, facecolor="white")
fig.savefig(OUTPUTS / "Hyperliquid_Funding_Heatmap.svg", facecolor="white")
plt.close(fig)

print(json.dumps({"funding": stats, "volume": volume, "regime_counts": regime_spec["counts"], "figure": str(OUTPUTS / "Hyperliquid_Funding_Heatmap.png")}, indent=2))
