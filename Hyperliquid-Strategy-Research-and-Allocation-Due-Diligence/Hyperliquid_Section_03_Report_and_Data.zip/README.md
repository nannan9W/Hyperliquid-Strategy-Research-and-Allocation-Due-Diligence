# Hyperliquid Section 3: report, funding figure, and reproducible data

## Deliverables

- Hyperliquid_Report_Section_03.md: English manuscript followed by Chinese working notes and precise instructions for the remaining historical order-book analysis.
- outputs/Hyperliquid_Funding_Heatmap.png: publication figure.
- outputs/Hyperliquid_Funding_Heatmap.svg: editable vector version.
- outputs/section03_statistics.json: full-precision funding distribution, transitions, episode statistics, monthly values, and base-unit volume comparisons.
- outputs/funding_spells.json: every observed positive/negative funding run, including boundary flags.
- outputs/liquidity_regime_calendar.json: a price-derived date classification for the proposed normal/stress liquidity study. It does not contain observed spread or depth results.
- inputs/: frozen official JSON observations first retrieved on 2026-09-09 for the 2025-09-01 to 2026-08-31 UTC observation period.
- build_section03.py: offline reproduction script.
- archive_access_probe.json: scope and result of the unsuccessful anonymous archive probes.
- MANIFEST.json: packaged file hashes and coverage limits.

## Reproduction

Use Python with numpy, pandas, and matplotlib installed. From this directory:

```bash
python3 build_section03.py
```

The script has no network calls, account operations, or paid data requests. It overwrites only its own files in outputs.

## Definitions

Mean hourly funding = arithmetic mean of actual settlement rates × 10,000, in basis points per hour. Positive-hour share = count(rate > 0) / valid hourly observations. Rates are not annualized. One basis point is 0.01 percentage points.

Direct sign switches count adjacent positive-to-negative or negative-to-positive changes. Zeros would break episodes and would not count as direct sign switches; neither input series contains zero rates. Episodes are consecutive equal-sign hours. Boundary censoring is retained in the episode records. No negative episode in this sample is boundary censored.

Volume ratios use sums of the reported candle v field in mapped base units: UBTC versus BTC, and UETH versus ETH. They are neither dollar turnover nor platform-wide market shares. Economic equivalence and redemption dependencies require separate review.

The proposed normal/stress reference is BTC perpetual daily log(high/low). Stress is at or above its full-window 90th percentile; normal is within its 40th–60th percentile range. This is an ex-post descriptive classification. Comparing liquidity requires actual synchronized historical books, common calendar/time strata, equal day weighting, and missingness/censoring disclosure.

## Limits

Only funding statistics, price-derived regime labels, base-unit turnover ratios, and their source grids are evaluated here. Historical dollar OI, full-market concentration, quoted spread, depth, execution costs, net carry returns and strategy capacity are not verified. The second requested figure, normal/stress spread and depth distributions, is not generated because the required historical L2 observations were unavailable in this session.

Current snapshots are not substituted for the historical sample. No fabricated or simulated order books are included. The source documentation states that official archives can be delayed or incomplete and that requesters pay transfer costs.

See the report working notes for official archive paths, the exact missing fields, and the remaining data-processing requirements.
