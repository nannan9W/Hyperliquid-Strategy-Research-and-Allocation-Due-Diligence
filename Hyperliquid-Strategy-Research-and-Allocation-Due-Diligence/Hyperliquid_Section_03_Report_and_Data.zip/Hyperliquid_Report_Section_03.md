# 3. Market Structure & Strategy Opportunity

Across September 2025–August 2026, BTC and ETH funding was positive in **81.5% and 83.0%** of hours, respectively. Median hourly rates were 0.125 basis points for both, while means were lower at 0.069 and 0.070 bps. BTC recorded **736** direct sign switches and ETH **764**. Negative episodes had a two-hour median but lasted up to **45 and 64 hours**. Both monthly averages turned negative in April despite positive funding in most hours (Figure 1). These observations motivate carry research with explicit reversal and execution costs.

Reported UBTC and UETH spot turnover equalled **1.90% and 1.48%** of their corresponding perpetual turnover in mapped base units. This imbalance makes spot-side liquidity a separate capacity question; turnover alone does not establish executable depth.

Three measures must remain distinct:

| Measure | Interpretation |
|---|---|
| Executable spot–perpetual basis | Synchronized sell-perpetual/buy-spot VWAP spread at a specified size, before fees |
| Mark–oracle deviation | Difference between valuation and reference prices; a risk measure |
| Funding rate | Hourly transfer rate between perpetual longs and shorts |

Funding payments use the applicable position and oracle price. [Hyperliquid funding documentation](https://hyperliquid.gitbook.io/hyperliquid-docs/trading/funding)

The liquidity comparison is specified using BTC’s daily log(high/low) range: top-decile days are “stress” (**37 days**), and 40th–60th-percentile days are “normal” (**73 days**). Comparisons require historical books in common month/time-of-day strata, with equal day weighting. These are ex-post descriptors, not trading signals.

Historical dollar OI, venue-wide concentration, and spread/depth distributions remain unverified. The available evidence therefore supports further strategy testing, without establishing capacity at scale. Applicable historical margin tiers and cross/isolated rules must be reconstructed; liquidation depends on mark prices and maintenance margin. [Margining](https://hyperliquid.gitbook.io/hyperliquid-docs/trading/margining), [liquidations](https://hyperliquid.gitbook.io/hyperliquid-docs/trading/liquidations).

Messari’s priority-fee research also identifies execution ordering as an additional competitive cost for latency-sensitive strategies. [Messari Priority Fees research](https://messari.io/report/hyper-liquid-priority-fees-internalizing-high-frequency-trading-revenue)

**Figure 1.** Monthly mean hourly funding and positive-hour shares. Each asset contributes 8,760 observations. Source: Hyperliquid Info API, retrieved 9 September 2026; author calculations. Rates do not represent strategy returns.

---

# 作者工作说明：图表、取数与尚未完成的验证

本节延续全文 3,000–4,000 英文词的限制。以上英文为当前正文草稿；以下工作说明不纳入英文成稿。历史点差／深度图、美元 OI 与全市场集中度需要补数据后定稿。

## 已完成：资金费率热力图与统计

图文件位于 outputs/Hyperliquid_Funding_Heatmap.png，另有可编辑 SVG。无需再去 Messari 截取资金费率图。

- 上半图：每月实际小时资金费率的算术平均，单位为 bps/hour，即原始 fundingRate × 10,000。它没有年化，也不是策略本金收益率。
- 下半图：每月资金费率大于零的小时占比，计算为正费率小时数／该月有效小时数。
- 正负切换：只统计相邻小时由正变负或由负变正。本样本没有零费率小时。
- 持续时间：连续相同符号的小时构成一个 episode。负费率区间在两端均未遭遇样本边界截断；正费率区间的边界截断另有标记。
- BTC、ETH 各包含 8,760 个小时观测。逐月数值、分位数、切换次数及每段起止时间均在 outputs 中。

正文中现货／永续成交量比值来自日线 v 字段的全年合计，采用名义映射后的基础资产单位。它不是美元成交额，不是全交易所市场份额，也不能替代点差或深度。

## 尚缺：正常与压力时段的点差、深度分布

本次对官方 S3 归档中一个资产上下文文件和一个 BTC L2 文件的访问尝试均返回 HTTP 403，未取得历史数据。403 不能证明对象不存在，也不能据此判断整个归档的覆盖情况。官方文档说明归档可能延迟或缺失，并由请求者承担传输费用。[官方历史数据说明](https://hyperliquid.gitbook.io/hyperliquid-docs/historical-data)

单张交易界面截图只能记录一个时点，无法形成正常／压力时段的分布。因此第二张必做图需要时间序列导出，不建议通过人工截图拼接。

### 去哪里取数

| 要完成的分析 | 官方数据位置／字段 | 使用要求 |
|---|---|---|
| BTC、ETH 永续点差及深度 | hyperliquid-archive 的 market_data/[YYYYMMDD]/[hour]/l2Book/BTC.lz4 或 ETH.lz4 | 保留时间戳、买卖方向、各档价格和数量；先确认实际格式与日期覆盖 |
| 美元 OI、Mark／Oracle、成交额 | asset_ctxs/[YYYYMMDD].csv.lz4 中的市场标识、openInterest、markPx、oraclePx、dayNtlVlm（以实际归档字段为准） | 按有效合约定义、计价币与时点换算；不能把滚动 24h 成交量快照逐小时累加 |
| 全市场集中度 | 同一时点、同一口径下的完整市场集合 | 区分 Core 与 HIP-3；市场主键包含 DEX 名称，不把同名合约混在一起 |
| UBTC／UETH 现货对冲流动性 | 单独核实对应现货市场的历史 L2 是否可取得 | 官方归档不保证完整现货历史；若只能自行采样，应使用实际采样期，不能回填到历史研究期 |

下面只是验证权限和文件格式的下载示例，两个文件本身不足以支持全样本对比。命令需要使用你自己的 AWS 配置，费用按官方 requester-pays 规则处理；无需向我提供任何密钥。

```bash
aws s3 cp s3://hyperliquid-archive/market_data/20260831/0/l2Book/BTC.lz4 ./BTC_20260831_00.lz4 --request-payer requester
aws s3 cp s3://hyperliquid-archive/asset_ctxs/20260831.csv.lz4 ./asset_ctxs_20260831.csv.lz4 --request-payer requester
```

通过格式与覆盖检查后，再依据 outputs/liquidity_regime_calendar.json 中的日期取得正常与压力样本。历史归档名称、字段和市场覆盖均应以实际返回为准，不能仅凭当前 API 示例推定历史格式。

### 第二张图的计算口径

1. **市场与采样。** 首先对 BTC、ETH 永续分别作图，研究 UBTC、UETH 现货时单列。使用同步时间网格，例如每分钟一笔，预先约定最大快照年龄；不要把交易更新最密集的压力时段自动赋予更高权重。
2. **正常／压力划分。** 已根据 BTC 日线计算出 37 个 top-decile 压力日、73 个位于 40%–60% 分位的正常日，其余 255 日不进入这项对比。这是根据价格振幅建立的事后分类，尚不是已经观察到的流动性状态。
3. **可比性。** 在月份及 UTC 时段有共同支持的样本内比较，按日期等权，分别报告每组缺失率。该设计描述条件差异，不证明价格压力对流动性的因果效应。
4. **点差。** mid = (ask1 + bid1) / 2；spread_bps = 10,000 × (ask1 − bid1) / mid。
5. **可见深度。** 分别累计 mid 上下 10 bps 内买侧与卖侧的 price × size。报告币种（如 USDC），并可用两侧较小值描述对称可见深度；不要让一侧的厚度掩盖另一侧的不足。
6. **截断与异常。** 当前 l2Book API 最多提供每侧 20 档。若档位不能覆盖 ±10 bps，深度只能视为下界并标记截断；除非确认完整订单簿，否则不能当作完整带内深度。空簿、交叉报价、过期快照与缺失时段需单独记录。[官方 L2 接口](https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/info-endpoint)
7. **作图。** 使用 BTC／ETH × 正常／压力分组的点差与深度分布图，可采用箱线图并补充 P95／P99，或完整经验分布函数。未取得历史 L2 前，不绘制模拟曲线冒充历史结果。

建议保留的标准化字段：timestamp_utc、dex、market、quote_currency、bid1、ask1、bid_depth_10bps、ask_depth_10bps、book_age_ms、depth_truncated、regime。原始各档数据也应保留，便于复算 VWAP 与不同规模冲击成本。

### 美元 OI 与集中度的处理

对所研究线性合约，先核实 openInterest 的单位及合约乘数，再以相应 markPx 换算名义价值；若以 USDC 计价，应明确其与美元之间的计价假设。不能把多空两侧再重复加总。

成交额优先使用成交价格×成交数量的逐笔合计，或口径明确的官方成交额字段；日线 v×收盘价不是精确美元成交额。固定时点的 24h 成交额可用于同口径比较，但高频滚动快照不可直接相加。

Top-5 share = 同一时点前五市场成交额／同一研究集合全部市场成交额。缺失 HIP-3 市场时只能报告 Core 集合的集中度；只研究 BTC 与 ETH 时不能报告全平台集中度。

不同合约的风险比较需保存当时有效的保证金档位、cross／isolated 设置、维持保证金规则和合约／部署方变更记录。今天的元数据不能自动证明历史规则。

## Messari 的使用位置

本节使用 Messari 的 Priority Fees 研究解释交易执行竞争与费用约束。它研究的市场集合与时间窗口需按原文理解，不能把其高频策略样本成本直接套用到本报告的资金费率策略。

如需保留研究背景截图，打开该报告的 Economic Effects of Priority Fees 部分，保留标题与发布日期作为资料记录即可。HYPE 的聚合资金费率图不能作为 Hyperliquid BTC／ETH 永续资金费率或全平台数据的替代品。
