"""Read-only, resumable HLP event collection with bounded API request pacing."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import math
import threading
import time
import urllib.request
import urllib.error
import pandas as pd

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"
PAGES = INPUTS / "ledger_pages"
PAGES.mkdir(parents=True, exist_ok=True)
HLP = "0xdfc24b077bc1425ad1dea75bcb6f8158e10df303"
URL = "https://api.hyperliquid.xyz/info"
gate = threading.Lock()
next_request = 0.0

def request(payload):
    global next_request
    for attempt in range(6):
        with gate:
            scheduled = max(time.monotonic(), next_request)
            next_request = scheduled + 6.1  # conservative: <=120 weight per ledger page
        remaining = scheduled - time.monotonic()
        while remaining > 0:
            time.sleep(min(remaining, 1.0))
            remaining = scheduled - time.monotonic()
        req = urllib.request.Request(URL, data=json.dumps(payload).encode(),
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=35) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code not in (429, 500, 502, 503, 504) or attempt == 5:
                raise
            wait = min(float(e.headers.get("Retry-After", 2 ** (attempt + 1))), 50)
            print(json.dumps({"retry_http": e.code, "wait_seconds": wait}), flush=True)
            time.sleep(wait)
        except (urllib.error.URLError, TimeoutError):
            if attempt == 5:
                raise
            time.sleep(min(2 ** attempt, 15))
    raise RuntimeError("request exhausted")

def event_key(row):
    return hashlib.sha256(json.dumps(row, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

def month_job(start, end):
    label = start.strftime("%Y-%m")
    cursor = int(start.timestamp() * 1000)
    end_ms = int(end.timestamp() * 1000) - 1
    seen, collected, pages = set(), [], []
    for page_no in range(1, 301):
        payload = {"type": "userNonFundingLedgerUpdates", "user": HLP, "startTime": cursor, "endTime": end_ms}
        path = PAGES / f"{label}_{page_no:03d}.json"
        if path.exists():
            obj = json.loads(path.read_text())
            assert obj["request"] == payload, (path, "resume request mismatch")
            rows = obj["response"]
        else:
            raw = request(payload)
            assert isinstance(raw, list)
            rows = []
            for r in raw:
                item = {"time": r["time"], "hash": r["hash"], "event_key": event_key(r),
                        "delta": {k: v for k, v in r["delta"].items() if k != "user"}}
                rows.append(item)
            obj = {"endpoint": URL, "request": payload, "retrieved_at": datetime.now(timezone.utc).isoformat(),
                   "normalization": "Withdrawer identity omitted; event key is SHA-256 of full original event", "response": rows}
            path.write_text(json.dumps(obj, indent=2) + "\n")
        pages.append({"file": path.name, "rows": len(rows), "startTime": cursor})
        if not rows:
            return {"month": label, "pagination_exhausted": True, "events": collected, "pages": pages}
        assert all(cursor <= int(r["time"]) <= end_ms for r in rows)
        fresh = 0
        for r in rows:
            if r["event_key"] not in seen:
                seen.add(r["event_key"])
                collected.append(r)
                fresh += 1
        last = max(r["time"] for r in rows)
        print(json.dumps({"month": label, "page": page_no, "rows": len(rows), "new": fresh,
                          "last": datetime.fromtimestamp(last/1000, timezone.utc).isoformat()}), flush=True)
        if last == cursor:
            if len(rows) >= 2000:
                raise RuntimeError(f"Saturated timestamp boundary {label} {cursor}; cannot prove complete pagination")
            cursor = last + 1
        else:
            cursor = last  # overlap the boundary rather than silently skipping equal-time events
        if cursor > end_ms:
            return {"month": label, "pagination_exhausted": True, "events": collected, "pages": pages}
    raise RuntimeError(f"Unexpected pagination length: {label}")

def main():
    boundaries = pd.date_range("2025-09-01", "2026-09-01", freq="MS", tz="UTC")
    results = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        jobs = [pool.submit(month_job, boundaries[i], boundaries[i+1]) for i in range(12)]
        for future in as_completed(jobs):
            r = future.result()
            results.append(r)
            (INPUTS / f"ledger_month_{r['month']}.json").write_text(json.dumps(r, indent=2) + "\n")
            print(json.dumps({"completed_month": r["month"], "events": len(r["events"])}), flush=True)
    results.sort(key=lambda r:r["month"])
    all_events = sorted([r for m in results for r in m["events"]], key=lambda r:(r["time"], r["event_key"]))
    assert len({r["event_key"] for r in all_events}) == len(all_events)
    final = {"source": URL, "account": HLP, "start_utc": boundaries[0].isoformat(), "end_exclusive_utc": boundaries[-1].isoformat(),
             "retrieval_finished_utc": datetime.now(timezone.utc).isoformat(), "pagination_exhausted_all_months": True,
             "independently_reconciled": False, "event_count": len(all_events),
             "months": [{k:v for k,v in m.items() if k!='events'} for m in results], "events": all_events}
    (INPUTS / "hlp_ledger_complete_query.json").write_text(json.dumps(final, indent=2) + "\n")
    print(json.dumps({"finished": True, "total_events": len(all_events), "pages": sum(len(m['pages']) for m in results)}), flush=True)

if __name__ == "__main__":
    main()
