"""Offline HLP evidence analysis. All inputs are frozen official API responses.

Run with Python 3, numpy, pandas, and matplotlib. No network or credentials needed.
The result is a linked Modified Dietz estimate, not an exact investor unit NAV.
"""
from pathlib import Path
from decimal import Decimal
from collections import Counter
from datetime import datetime, timezone
import json
import math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import FuncFormatter, MaxNLocator

ROOT = Path(__file__).resolve().parent
INPUTS, OUT = ROOT / "inputs", ROOT / "outputs"
OUT.mkdir(exist_ok=True)
HLP = "0xdfc24b077bc1425ad1dea75bcb6f8158e10df303"
START = pd.Timestamp("2025-09-01", tz="UTC")
END = pd.Timestamp("2026-09-01", tz="UTC")
D = Decimal


def read(name):
    return json.loads((INPUTS / name).read_text())


def write(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def utc(ms):
    return datetime.fromtimestamp(ms / 1000, timezone.utc).isoformat()


def classify_events(ledger):
    assert ledger["pagination_exhausted_all_months"]
    assert len(ledger["events"]) == len({r["event_key"] for r in ledger["events"]})
    assert len(ledger["months"]) == 12
    classified, unusual = [], []
    for row in ledger["events"]:
        delta = row["delta"]
        kind, vault = delta["type"], delta.get("vault")
        cf, category = D(0), ""
        if kind == "vaultDeposit" and vault == HLP:
            cf, category = D(delta["usdc"]), "investor_deposit"
        elif kind == "vaultWithdraw" and vault == HLP:
            # No leader share or closing charge is assumed away: stop if one appears.
            assert D(delta.get("commission", "0")) == 0, row
            assert D(delta.get("closingCost", "0")) == 0, row
            cf, category = -D(delta["netWithdrawnUsd"]), "investor_withdrawal"
        elif kind in {"vaultDeposit", "vaultWithdraw", "vaultCreate"} and vault != HLP:
            # Parent cash <-> owned vault interest is a balance-sheet reallocation.
            # The official parent's accountValue already includes vault balances.
            category = "owned_vault_reallocation"
            if kind == "vaultCreate":
                assert D(delta.get("fee", "0")) == 0, row
        elif kind == "internalTransfer" and delta.get("destination") == HLP:
            # Inward account-level transfer, kept separate from investor subscriptions.
            # The API's 'internalTransfer' means platform-internal, not intra-HLP.
            cf, category = D(delta["usdc"]), "other_inward_transfer"
            unusual.append(row)
        else:
            raise ValueError(f"Unclassified ledger event; investigate before publishing: {row}")
        classified.append({"time": row["time"], "event_key": row["event_key"],
                           "category": category, "external_flow_usdc": float(cf),
                           "external_flow_decimal": str(cf)})
    return classified, unusual


def valuations():
    obj = read("hlp_portfolio_snapshot.json")
    periods = dict(obj["portfolio"])
    av = {t: D(v) for t, v in periods["allTime"]["accountValueHistory"]}
    ap = {t: D(v) for t, v in periods["allTime"]["pnlHistory"]}
    mv = {t: D(v) for t, v in periods["month"]["accountValueHistory"]}
    mp = {t: D(v) for t, v in periods["month"]["pnlHistory"]}
    overlap = sorted(set(av) & set(mv))
    assert overlap
    offsets = [ap[t] - mp[t] for t in overlap]
    assert max(offsets) - min(offsets) < D("0.000001")
    offset = sum(offsets) / D(len(offsets))
    combined = {}
    for t in sorted(set(av) | set(mv)):
        if t in av and t in mv:
            assert abs(av[t] - mv[t]) < D("0.000001")
        value = av[t] if t in av else mv[t]
        pnl = ap[t] if t in ap else mp[t] + offset
        combined[t] = {"time": t, "datetime_utc": utc(t), "account_value_usdc": float(value),
                       "reported_pnl_aligned_usdc": float(pnl),
                       "source_period": "allTime" if t in av else "month",
                       "decimal_value": str(value), "decimal_pnl": str(pnl)}
    return list(combined.values()), sorted(av), {"overlap_points": len(overlap),
        "month_to_allTime_pnl_offset_usdc": str(offset),
        "max_overlap_offset_disagreement_usdc": str(max(offsets)-min(offsets))}


def build_returns(vals, events):
    times = np.array([r["time"] for r in events], dtype=np.int64)
    records = []
    nav, high = 100.0, 100.0
    curve = [{**vals[0], "nav_index_estimate": nav, "drawdown_estimate": 0.0}]
    for a, b in zip(vals, vals[1:]):
        lo = int(np.searchsorted(times, a["time"], side="right"))
        hi = int(np.searchsorted(times, b["time"], side="right"))
        flows = events[lo:hi]
        total = sum((D(r["external_flow_decimal"]) for r in flows), D(0))
        weighted = sum((D(b["time"]-r["time"]) / D(b["time"]-a["time"]) *
                        D(r["external_flow_decimal"]) for r in flows), D(0))
        begin, finish = D(a["decimal_value"]), D(b["decimal_value"])
        earnings = finish - begin - total
        denom = begin + weighted
        if denom <= 0:
            raise ValueError("Nonpositive Modified Dietz capital denominator")
        ret = float(earnings / denom)
        if ret <= -1:
            raise ValueError("Nonpositive NAV factor")
        reported = D(b["decimal_pnl"]) - D(a["decimal_pnl"])
        residual = earnings - reported
        nav *= 1 + ret
        high = max(high, nav)
        record = {"start_time": a["time"], "end_time": b["time"],
                  "start_utc": a["datetime_utc"], "end_utc": b["datetime_utc"],
                  "days": (b["time"]-a["time"]) / 86_400_000,
                  "begin_equity_usdc": float(begin), "end_equity_usdc": float(finish),
                  "external_net_flow_usdc": float(total),
                  "weighted_external_net_flow_usdc": float(weighted),
                  "modified_dietz_capital_usdc": float(denom),
                  "reconstructed_profit_usdc": float(earnings),
                  "reported_pnl_change_usdc": float(reported),
                  "reconciliation_residual_usdc": float(residual),
                  "reconciliation_residual_bps_of_begin_equity": float(residual / begin * 10000),
                  "external_flow_events": sum(r["external_flow_decimal"] != "0" for r in flows),
                  "return_estimate": ret, "nav_index_estimate": nav,
                  "drawdown_estimate": nav / high - 1}
        records.append(record)
        curve.append({**b, "nav_index_estimate": nav, "drawdown_estimate": nav / high - 1})
    return records, curve


def monthly_flows(events):
    rows = []
    for start in pd.date_range(START, END, freq="MS", inclusive="left"):
        end = start + pd.offsets.MonthBegin(1)
        es = [r for r in events if start.value//10**6 <= r["time"] < end.value//10**6]
        by = {k: sum((D(r["external_flow_decimal"]) for r in es if r["category"] == k), D(0))
              for k in ["investor_deposit", "investor_withdrawal", "other_inward_transfer"]}
        rows.append({"month": start.strftime("%Y-%m"), "start_utc": start.isoformat(),
                     "end_exclusive_utc": end.isoformat(),
                     "investor_deposits_usdc": float(by["investor_deposit"]),
                     "investor_withdrawals_usdc": float(-by["investor_withdrawal"]),
                     "investor_net_inflow_usdc": float(by["investor_deposit"]+by["investor_withdrawal"]),
                     "other_inward_transfers_usdc": float(by["other_inward_transfer"]),
                     "event_count": len(es)})
    return rows


def market_intervals(curve, coarse_times):
    nav_by = {r["time"]: r["nav_index_estimate"] for r in curve}
    prices, matches = {}, {}
    for asset in ["BTC", "ETH"]:
        cs = sorted(read(f"{asset.lower()}_perp_4h.json")["response"], key=lambda x:x["T"])
        times = np.array([c["T"] for c in cs])
        prices[asset], matches[asset] = {}, {}
        for t in coarse_times:
            i = int(np.searchsorted(times, t, side="right"))-1
            assert i >= 0
            c = cs[i]
            age = (t-c["T"])/3_600_000
            assert 0 <= age < 4
            prices[asset][t] = float(c["c"])
            matches[asset][t] = {"candle_close_time": c["T"], "price": float(c["c"]), "age_hours": age}
    rows = []
    for t0, t1 in zip(coarse_times, coarse_times[1:]):
        r = {"start_time": t0, "end_time": t1, "start_utc": utc(t0), "end_utc": utc(t1),
             "days": (t1-t0)/86_400_000,
             "hlp_return_estimate": nav_by[t1]/nav_by[t0]-1}
        for asset in ["BTC", "ETH"]:
            r[asset+"_price_return"] = prices[asset][t1]/prices[asset][t0]-1
            r[asset+"_begin_price_match"] = matches[asset][t0]
            r[asset+"_end_price_match"] = matches[asset][t1]
        rows.append(r)
    return rows


def rolling_beta(rows, window=8):
    # Two SEPARATE univariate regressions. Betas are not additive portfolio weights.
    # HC3 covariance with a t(6) critical value; exploratory small-sample bands.
    crit_t6 = 2.446911851144969
    out = []
    for stop in range(window, len(rows)+1):
        sample = rows[stop-window:stop]
        y = np.array([r["hlp_return_estimate"] for r in sample])
        for asset in ["BTC", "ETH"]:
            x = np.array([r[asset+"_price_return"] for r in sample])
            X = np.column_stack([np.ones(len(x)), x])
            inverse = np.linalg.inv(X.T @ X)
            coeff = inverse @ X.T @ y
            residual = y-X@coeff
            hat = np.einsum("ij,jk,ik->i", X, inverse, X)
            assert np.all(hat < 1)
            scaled = residual/(1-hat)
            cov = inverse @ (X.T @ (X * scaled[:,None]**2)) @ inverse
            se = float(np.sqrt(cov[1,1]))
            r2 = 1 - float(residual@residual)/float((y-y.mean())@(y-y.mean()))
            out.append({"asset": asset, "window_observations": window,
                        "start_utc": sample[0]["start_utc"], "end_utc": sample[-1]["end_utc"],
                        "end_time": sample[-1]["end_time"],
                        "window_days": sum(r["days"] for r in sample),
                        "beta": float(coeff[1]), "intercept": float(coeff[0]),
                        "hc3_standard_error": se, "approx_95_low": float(coeff[1]-crit_t6*se),
                        "approx_95_high": float(coeff[1]+crit_t6*se), "r_squared": r2})
    return out


INK, MUTED, GRID = "#172B46", "#52647A", "#DFE5EB"
TEAL, BLUE, RED, ORANGE = "#007F79", "#345FC9", "#BE4B53", "#CE842B"


def style():
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
        "text.color": INK, "axes.labelcolor": MUTED, "xtick.color": MUTED,
        "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False,
        "axes.spines.left": False, "axes.spines.bottom": False,
        "axes.axisbelow": True, "figure.facecolor": "white", "axes.facecolor": "white",
        "svg.fonttype": "none", "savefig.facecolor": "white"})


def title(fig, num, name, subtitle):
    fig.text(.08, .965, f"HYPERLIQUID RESEARCH   /   FIGURE {num}", fontsize=10, color=TEAL, weight="bold")
    fig.text(.08, .925, name, fontsize=23, weight="bold")
    fig.text(.08, .888, subtitle, fontsize=11, color=MUTED)


def axis(ax):
    ax.grid(axis="y", color=GRID, lw=.75)
    ax.tick_params(length=0, pad=8)
    ax.yaxis.set_major_locator(MaxNLocator(5))


def dates(ax, xmin, xmax):
    ax.set_xlim(xmin-pd.Timedelta(days=5), xmax+pd.Timedelta(days=6))
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y", tz=timezone.utc))


def save(fig, name):
    fig.savefig(OUT / (name+".png"), dpi=200)
    fig.savefig(OUT / (name+".svg"))
    plt.close(fig)


def figures(curve, monthly, betas, summary):
    style()
    dt = pd.to_datetime([r["time"] for r in curve], unit="ms", utc=True)
    nav = np.array([r["nav_index_estimate"] for r in curve])
    dd = np.array([r["drawdown_estimate"] for r in curve])*100
    fig = plt.figure(figsize=(13, 8.5))
    title(fig, "5.1", "HLP cash-flow-adjusted performance", "Linked Modified Dietz estimate  |  3 Sep 2025–31 Aug 2026 UTC  |  48 observed valuations")
    ax = fig.add_axes([.08,.405,.85,.395]); bx=fig.add_axes([.08,.175,.85,.175], sharex=ax)
    axis(ax); axis(bx)
    ax.plot(dt, nav, color=TEAL, lw=2.2, marker="o", ms=3.1)
    ax.axhline(100, color=MUTED, lw=.9, ls="--", alpha=.55)
    ax.set_ylabel("Estimated NAV index (start = 100)", labelpad=12)
    ax.set_ylim(min(99,float(nav.min())-1), float(nav.max())+2)
    ax.text(.015,.94, f"Period return  {summary['linked_return_estimate']:+.2%}", transform=ax.transAxes, fontsize=14, weight="bold", va="top")
    bx.fill_between(dt, dd, 0, color=RED, alpha=.18)
    bx.plot(dt,dd,color=RED,lw=1.5,marker="o",ms=2.8)
    bx.axhline(0,color=MUTED,lw=.7)
    bx.set_ylabel("Drawdown (%)",labelpad=12)
    bx.set_ylim(min(float(dd.min())*1.6,-.1), .02)
    bx.text(.015,.1, f"Largest observed drawdown  {summary['max_observed_drawdown_estimate']:.2%}", transform=bx.transAxes, fontsize=11)
    plt.setp(ax.get_xticklabels(),visible=False)
    dates(bx,dt[0],dt[-1])
    fig.text(.08,.075,"Points are API valuation observations; connecting lines do not reconstruct intervening returns. Daily or intraday losses may be larger.",fontsize=9.2,color=MUTED)
    fig.text(.08,.047,"Source: Hyperliquid official vaultDetails + fully paginated account ledger. Author calculations; approximate return, not exact unit NAV.",fontsize=9.2,color=MUTED)
    save(fig,"Figure_5_1_HLP_Adjusted_NAV_Drawdown")

    fig = plt.figure(figsize=(13,8.5))
    title(fig,"5.2","HLP visible assets and investor flows","Observed parent account value and calendar-month subscriptions less withdrawals  |  USDC millions")
    ax=fig.add_axes([.08,.48,.85,.32]); bx=fig.add_axes([.08,.19,.85,.21],sharex=ax)
    axis(ax);axis(bx)
    eq=np.array([r["account_value_usdc"] for r in curve])/1e6
    ax.plot(dt,eq,color=BLUE,lw=2.2,marker="o",ms=3.1)
    ax.set_ylabel("Visible assets (USDC m)",labelpad=12)
    ax.set_ylim(0,max(eq)*1.17)
    ax.text(.015,.94,f"First observation  {eq[0]:,.1f}m    |    Last observation  {eq[-1]:,.1f}m",transform=ax.transAxes,fontsize=13,weight="bold",va="top")
    md=pd.to_datetime([r["start_utc"] for r in monthly])+pd.Timedelta(days=14)
    flow=np.array([r["investor_net_inflow_usdc"] for r in monthly])/1e6
    bx.bar(md,flow,width=20,color=[TEAL if v>=0 else RED for v in flow],alpha=.92)
    bx.axhline(0,color=MUTED,lw=.8)
    bx.set_ylabel("Net investor inflow (USDC m)",labelpad=12)
    bx.set_ylim(min(flow)*1.32,max(max(flow)*1.65,20))
    for x,v in zip(md,flow):
        bx.annotate(f"{v:+.1f}",(x,v),xytext=(0,4 if v>=0 else -13),textcoords="offset points",ha="center",fontsize=9,color=MUTED)
    plt.setp(ax.get_xticklabels(),visible=False)
    dates(bx,START,END-pd.Timedelta(days=1))
    bx.set_xticks(md)
    bx.set_xticklabels([pd.Timestamp(t).strftime("%b\n%Y") if i in [0,4] else pd.Timestamp(t).strftime("%b") for i,t in enumerate(md)],fontsize=10)
    fig.text(.08,.095,"Assets: actual observations from 3 Sep 2025. Flow bars: complete calendar months, 1 Sep 2025–31 Aug 2026 UTC.",fontsize=9.2,color=MUTED)
    fig.text(.08,.067,f"Owned-vault reallocations are excluded from external flows. Other inward transfers ({summary['full_calendar_other_inward_transfers_usdc']:.2f} USDC) are reported separately.",fontsize=9.2,color=MUTED)
    fig.text(.08,.039,"Source: Hyperliquid official account data. Visible vault assets do not represent a manager’s complete AUM; child equity is not added twice.",fontsize=9.2,color=MUTED)
    save(fig,"Figure_5_2_HLP_Assets_Net_Flows")

    fig=plt.figure(figsize=(13,8.5))
    title(fig,"5.3","HLP rolling market sensitivity","Return-implied beta estimate  |  8 observed return intervals per window (about 16 weeks)")
    ax=fig.add_axes([.08,.505,.85,.285]); bx=fig.add_axes([.08,.19,.85,.245],sharex=ax)
    for a,asset,color in [(ax,"BTC",ORANGE),(bx,"ETH",BLUE)]:
        rows=[r for r in betas if r["asset"]==asset]
        ts=pd.to_datetime([r["end_time"] for r in rows],unit="ms",utc=True)
        b=np.array([r["beta"] for r in rows]); low=np.array([r["approx_95_low"] for r in rows]);high=np.array([r["approx_95_high"] for r in rows])
        axis(a)
        a.fill_between(ts,low,high,color=color,alpha=.14,label="Approx. 95% HC3 band")
        a.plot(ts,b,color=color,lw=2,marker="o",ms=3.5,label=asset+" beta")
        a.axhline(0,color=MUTED,lw=1,ls="--")
        a.set_ylabel(asset+" beta",labelpad=12)
        a.legend(loc="upper right",frameon=False,ncol=2,fontsize=9.5)
    plt.setp(ax.get_xticklabels(),visible=False)
    dates(bx,pd.to_datetime(betas[0]["end_time"],unit="ms",utc=True),dt[-1])
    fig.text(.08,.095,"Separate BTC and ETH regressions: betas cannot be added. Bands are exploratory; short samples and overlapping windows limit inference.",fontsize=9.2,color=MUTED)
    fig.text(.08,.067,"This estimates return sensitivity, not historical holdings, gross leverage, or liquidation risk. Low beta does not establish market neutrality.",fontsize=9.2,color=MUTED)
    fig.text(.08,.039,"Source: reconstructed HLP returns and official BTC/ETH perpetual candles. Market prices use the last completed 4h candle before each valuation.",fontsize=9.2,color=MUTED)
    save(fig,"Figure_5_3_HLP_Rolling_Beta_Estimate")


def main():
    ledger=read("hlp_ledger_complete_query.json")
    events, unusual=classify_events(ledger)
    vals, coarse_times, alignment=valuations()
    records,curve=build_returns(vals,events)
    monthly=monthly_flows(events)
    market=market_intervals(curve,coarse_times)
    betas=rolling_beta(market)
    residuals=np.array([r["reconciliation_residual_usdc"] for r in records])
    # This gate tolerates API display/accounting rounding, not material unexplained PnL.
    residual_bps=np.array([abs(r["reconciliation_residual_bps_of_begin_equity"]) for r in records])
    assert max(residual_bps)<.01, ("Material ledger/PnL mismatch",max(residual_bps))
    within=[r for r in events if vals[0]["time"]<r["time"]<=vals[-1]["time"]]
    net_cf=float(sum((D(r["external_flow_decimal"]) for r in within),D(0)))
    top_two=sorted(records,key=lambda r:r["return_estimate"],reverse=True)[:2]
    summary={"scope":"HLP parent account; reported account values already include owned vault balances",
        "study_start_utc":START.isoformat(),"study_end_exclusive_utc":END.isoformat(),
        "valuation_first_utc":vals[0]["datetime_utc"],"valuation_last_utc":vals[-1]["datetime_utc"],
        "valuation_count":len(vals),"return_intervals":len(records),"coarse_market_return_intervals":len(market),
        "ledger_event_count":len(events),"ledger_pages":sum(len(m["pages"]) for m in ledger["months"]),
        "event_categories":dict(Counter(r["category"] for r in events)),
        "ledger_query_retrieval_finished_utc":ledger["retrieval_finished_utc"],
        "first_account_value_usdc":vals[0]["account_value_usdc"],"last_account_value_usdc":vals[-1]["account_value_usdc"],
        "account_value_change_usdc":vals[-1]["account_value_usdc"]-vals[0]["account_value_usdc"],
        "external_net_flow_between_valuations_usdc":net_cf,
        "reconstructed_profit_between_valuations_usdc":sum(r["reconstructed_profit_usdc"] for r in records),
        "reported_pnl_change_between_valuations_usdc":vals[-1]["reported_pnl_aligned_usdc"]-vals[0]["reported_pnl_aligned_usdc"],
        "reconciliation_residual_total_usdc":float(sum(residuals)),
        "reconciliation_residual_max_abs_interval_usdc":float(max(abs(residuals))),
        "reconciliation_residual_max_abs_bps":float(max(residual_bps)),
        "full_calendar_investor_net_flow_usdc":sum(r["investor_net_inflow_usdc"] for r in monthly),
        "full_calendar_other_inward_transfers_usdc":sum(r["other_inward_transfers_usdc"] for r in monthly),
        "linked_return_estimate":curve[-1]["nav_index_estimate"]/100-1,
        "max_observed_drawdown_estimate":min(r["drawdown_estimate"] for r in curve),
        "top_two_observed_intervals_log_return_share":sum(math.log1p(r["return_estimate"]) for r in top_two)/math.log(curve[-1]["nav_index_estimate"]/100),
        "top_two_observed_return_intervals":[{k:r[k] for k in ["start_utc","end_utc","return_estimate"]} for r in top_two],
        "beta_window_intervals":8,"beta_estimates_per_asset":len(betas)//2,
        "max_market_price_age_hours":max(r[a+"_"+e+"_price_match"]["age_hours"] for r in market for a in ["BTC","ETH"] for e in ["begin","end"]),
        "last_beta_estimates":{r["asset"]:{k:r[k] for k in ["beta","approx_95_low","approx_95_high","r_squared","window_days"]} for r in betas[-2:]},
        "pnl_series_alignment":alignment,
        "return_status":"Linked Modified Dietz estimate; approximate, irregular observations; not exact unit NAV or exact TWR",
        "risk_status":"Return-implied univariate betas; not reconstructed historical net/gross holdings"}
    write("audit_summary.json",summary)
    write("classified_external_flows.json",{"metadata":"USDC; deposits positive. Investor identities omitted.","rows":events})
    write("unusual_transfers.json",{"rows":unusual})
    write("nav_and_drawdown.json",{"method":"Linked Modified Dietz estimate at observed valuations", "rows":curve})
    write("return_interval_reconciliation.json",{"method":"Profit = end equity - begin equity - external flow", "rows":records})
    write("monthly_assets_flows_inputs.json",{"observed_assets":vals,"monthly_investor_flows":monthly})
    write("matched_market_returns.json",{"method":"Last completed official 4h candle; no forward price lookup", "rows":market})
    write("rolling_beta_estimates.json",{"method":"Separate univariate OLS, intercept, 8 intervals; HC3 and t(6) approximate bands", "rows":betas})
    figures(curve,monthly,betas,summary)
    print(json.dumps(summary,indent=2))


if __name__=="__main__":
    main()
