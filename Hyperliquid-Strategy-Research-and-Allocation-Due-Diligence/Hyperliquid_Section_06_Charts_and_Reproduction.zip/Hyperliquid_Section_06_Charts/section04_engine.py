"""Reproduce a CONDITIONAL carry model, tables and publication figures offline.

This is not an execution-validated backtest. See model_spec.json and README.md.
Requires Python 3, numpy, pandas, matplotlib. No API calls or trading operations.
"""
from pathlib import Path
import copy
import json
import math
import hashlib

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter, FuncFormatter

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)
SPEC = json.loads((ROOT / "model_spec.json").read_text())
START = pd.Timestamp(SPEC["period_start"])
END = pd.Timestamp(SPEC["period_end_exclusive"])
HOLDOUT = pd.Timestamp(SPEC["retrospective_holdout_start"])
WARMUP = pd.Timestamp("2025-08-25T00:00:00Z")
ASSETS = SPEC["assets"]
C0 = SPEC["capital_usdc"]
NAVY, TEAL, ORANGE, GREY = "#18334A", "#167F79", "#C56B3B", "#697982"


def plain(x):
    if isinstance(x, dict):
        return {str(k): plain(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [plain(v) for v in x]
    if isinstance(x, (pd.Timestamp,)):
        return x.isoformat()
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating, float)):
        return float(x) if math.isfinite(x) else None
    if isinstance(x, np.bool_):
        return bool(x)
    return x


def save_json(name, value):
    (OUT / name).write_text(json.dumps(plain(value), indent=2, allow_nan=False) + "\n")


def read_candles(asset, leg, interval):
    raw = json.loads((INPUTS / f"{asset}_{leg}_{interval}.json").read_text())["response"]
    frame = pd.DataFrame(raw).set_index("t").sort_index()
    frame.index = pd.to_datetime(frame.index, unit="ms", utc=True)
    for c in ("o", "h", "l", "c", "v"):
        frame[c] = pd.to_numeric(frame[c])
    return frame


def load_data():
    candles, funding, audit = {}, {}, {}
    expected_4h = pd.date_range(WARMUP, END, freq="4h", inclusive="left")
    expected_hours = pd.date_range(WARMUP, END, freq="h", inclusive="left")
    for asset in ASSETS:
        for leg in ("spot", "perp"):
            z = read_candles(asset, leg, "4h")
            assert z.index.is_unique and z.index.equals(expected_4h), (asset, leg, "candle coverage")
            assert np.isfinite(z[["o", "h", "l", "c", "v"]]).all().all()
            assert ((z[["o", "c"]].max(axis=1) <= z.h) &
                    (z[["o", "c"]].min(axis=1) >= z.l) & (z.l > 0) & (z.v > 0)).all()
            daily = read_candles(asset, leg, "daily")
            aggregate = z.resample("1D").agg({"o": "first", "h": "max", "l": "min", "c": "last", "v": "sum"})
            deviations = (aggregate.loc[daily.index, ["o", "h", "l", "c", "v"]]
                          - daily[["o", "h", "l", "c", "v"]]).abs().max()
            assert float(deviations[["o", "h", "l", "c"]].max()) == 0
            assert np.allclose(aggregate.loc[daily.index, "v"], daily.v, rtol=1e-10, atol=1e-8)
            audit[f"{asset}_{leg}"] = {"four_hour_rows": len(z), "main_period_rows": int((z.index >= START).sum()),
                                        "daily_ohlcv_max_absolute_differences": deviations.to_dict()}
            candles[(asset, leg)] = z
        warm = json.loads((INPUTS / f"{asset}_funding_warmup.json").read_text())["response"]
        main = json.loads((INPUTS / f"{asset}_funding_hourly.json").read_text())["rows"]
        f = pd.DataFrame(warm + main)
        f["hour"] = pd.to_datetime(f.time, unit="ms", utc=True).dt.floor("h")
        f = f.set_index("hour").sort_index()
        f["fundingRate"] = f.fundingRate.astype(float)
        assert f.index.is_unique and f.index.equals(expected_hours), (asset, "funding coverage")
        assert np.isfinite(f.fundingRate).all()
        funding[asset] = f.fundingRate
        audit[f"{asset}_funding"] = {"main_period_hours": int((f.index >= START).sum()), "warmup_hours": len(warm)}
    save_json("data_validation.json", audit)
    return candles, funding


CANDLES, FUNDING = load_data()
DAYS = pd.date_range(START, END, freq="D", inclusive="left")
HOURS = pd.date_range(START, END, freq="h", inclusive="left")

# Cache known historical observations independently of strategy and parameters.
OBS = {}
for t in HOURS:
    block = t.floor("4h")
    previous = block - pd.Timedelta(hours=4)
    OBS[t] = {
        "spot_proxy": np.array([CANDLES[(a, "spot")].loc[previous, "c"] for a in ASSETS], dtype=float),
        "perp_proxy": np.array([CANDLES[(a, "perp")].loc[previous, "c"] for a in ASSETS], dtype=float),
        "rates": np.array([FUNDING[a].loc[t] for a in ASSETS], dtype=float),
    }
    if t.hour % 4 == 0:
        OBS[t]["spot_open"] = np.array([CANDLES[(a, "spot")].loc[t, "o"] for a in ASSETS], dtype=float)
        OBS[t]["perp_open"] = np.array([CANDLES[(a, "perp")].loc[t, "o"] for a in ASSETS], dtype=float)


def simulate(version, lookback=None, cost_buffer=None, fee_multiplier=1.0, execution_bps=None, retain=False):
    lookback = lookback or SPEC["signal_lookback_hours"]
    cost_buffer = cost_buffer if cost_buffer is not None else SPEC["entry_cost_buffer"]
    execution_bps = execution_bps if execution_bps is not None else SPEC["execution_bps_per_leg_per_trade"]
    sf = SPEC["spot_fee_bps"] * 1e-4 * fee_multiplier
    pf = SPEC["perp_fee_bps"] * 1e-4 * fee_multiplier
    ec = execution_bps * 1e-4
    hurdle = cost_buffer * (2 * (sf + pf) + 4 * ec)
    q = np.zeros(2)
    equity = float(C0)
    perp_equity = C0 * SPEC["perp_collateral_target_fraction"]
    last_s, last_p = OBS[START]["spot_proxy"].copy(), OBS[START]["perp_proxy"].copy()
    comp = {"spot_price_pnl": 0.0, "perp_price_pnl": 0.0, "funding": 0.0,
            "fees": 0.0, "execution": 0.0, "financing_other": 0.0,
            "spot_traded_notional": 0.0, "perp_traded_notional": 0.0}
    trades, settlements = [], []
    decisions = []
    daily = [{"date": (START - pd.Timedelta(days=1)).date().isoformat(), "equity": equity, **comp}]
    stopped, min_coverage = False, math.inf
    stop_timestamp = None
    entries, exits = np.zeros(2, dtype=int), np.zeros(2, dtype=int)
    invested_hours = np.zeros(2, dtype=int)
    signals = {}
    for d in DAYS:
        lo = d - pd.Timedelta(hours=lookback)
        rates = np.array([FUNDING[a].loc[(FUNDING[a].index >= lo) & (FUNDING[a].index < d)].mean()
                          for a in ASSETS])
        assert all(len(FUNDING[a].loc[(FUNDING[a].index >= lo) & (FUNDING[a].index < d)]) == lookback
                   for a in ASSETS)
        vols = np.array([[CANDLES[(a, leg)].loc[(CANDLES[(a, leg)].index >= d - pd.Timedelta(days=1)) &
                         (CANDLES[(a, leg)].index < d), "v"].sum() for leg in ("spot", "perp")]
                         for a in ASSETS])
        s, p = OBS[d]["spot_proxy"], OBS[d]["perp_proxy"]
        gap = np.abs(p / s - 1) * 1e4
        signals[d] = {"mean": rates, "volumes": vols, "gap_bps": gap}

    def mark(s, p):
        nonlocal equity, perp_equity, last_s, last_p
        spot_pnl = float(np.sum(q * (s - last_s)))
        perp_pnl = float(np.sum(-q * (p - last_p)))
        equity += spot_pnl + perp_pnl
        perp_equity += perp_pnl
        comp["spot_price_pnl"] += spot_pnl
        comp["perp_price_pnl"] += perp_pnl
        last_s, last_p = s.copy(), p.copy()

    def transact(target, s, p, timestamp, reason):
        nonlocal equity, perp_equity, q
        delta = target - q
        fees = np.abs(delta) * (s * sf + p * pf)
        execution = np.abs(delta) * (s + p) * ec
        equity -= float(np.sum(fees + execution))
        perp_equity -= float(np.sum(np.abs(delta) * p * (pf + ec)))
        comp["fees"] += float(fees.sum())
        comp["execution"] += float(execution.sum())
        comp["spot_traded_notional"] += float(np.sum(np.abs(delta) * s))
        comp["perp_traded_notional"] += float(np.sum(np.abs(delta) * p))
        for j, a in enumerate(ASSETS):
            if q[j] <= 1e-12 < target[j]:
                entries[j] += 1
            if target[j] <= 1e-12 < q[j]:
                exits[j] += 1
            if abs(delta[j]) > 1e-12:
                trades.append({"timestamp_utc": timestamp.isoformat(), "asset": a, "reason": reason,
                               "old_q": q[j], "new_q": target[j], "delta_spot_q": delta[j],
                               "delta_perp_q": -delta[j], "spot_reference": s[j], "perp_reference": p[j],
                               "spot_notional": abs(delta[j]) * s[j], "perp_notional": abs(delta[j]) * p[j],
                               "fee": fees[j], "execution_cost": execution[j]})
        q = target.copy()

    for t in HOURS:
        ob = OBS[t]
        if t.hour % 4 == 0:
            mark(ob["spot_proxy"], ob["perp_proxy"])
        # Settle BEFORE any position change at this hour. Proxy is explicitly not oraclePx.
        fund = q * ob["spot_proxy"] * ob["rates"]
        equity += float(fund.sum())
        perp_equity += float(fund.sum())
        comp["funding"] += float(fund.sum())
        invested_hours += (q > 1e-12).astype(int)
        if retain:
            settlements.append({"hour_utc": t.isoformat(), "q_spot": q.tolist(), "q_perp": (-q).tolist(),
                                "hourly_rate": ob["rates"].tolist(),
                                "oracle_PROXY_prior_4h_spot_close": ob["spot_proxy"].tolist(),
                                "funding_cashflow_MODEL": fund.tolist()})
        if t.hour % 4 == 0:
            notional = float(np.sum(q * ob["perp_proxy"]))
            coverage = perp_equity / notional if notional > 0 else math.inf
            min_coverage = min(min_coverage, coverage)
            breach = coverage < SPEC["common_proxy_collateral_coverage_stop"]
            if breach and not stopped:
                stopped, stop_timestamp = True, t
                mark(ob["spot_open"], ob["perp_open"])
                transact(np.zeros(2), ob["spot_open"], ob["perp_open"], t, "common_proxy_collateral_stop")
        if t.hour == SPEC["execution_hour_utc"]:
            s, p = ob["spot_open"], ob["perp_open"]
            mark(s, p)
            d = t.floor("D")
            signal = signals[d]
            full_q = SPEC["spot_target_per_asset_fraction"] * equity / np.maximum(s, p)
            projected = signal["mean"] * SPEC["carry_projection_days"] * 24
            liquid = (full_q[:, None] <= SPEC["rule_max_position_prior_day_base_volume_fraction"] * signal["volumes"]).all(axis=1)
            basis_ok = signal["gap_bps"] < SPEC["rule_max_absolute_close_price_gap_bps"]
            if version == "passive":
                active = np.ones(2, dtype=bool)
            else:
                active = np.where(q > 1e-12, signal["mean"] > SPEC["exit_funding_mean_threshold"], projected > hurdle)
                active = active & liquid & basis_ok
            if stopped:
                active[:] = False
            # Solve weights against post-cost equity; no borrowed capital or external inflow.
            target = np.where(active, full_q, 0.0)
            for _ in range(12):
                delta = np.abs(target - q)
                cost = float(np.sum(delta * (s * sf + p * pf + (s + p) * ec)))
                target = np.where(active, SPEC["spot_target_per_asset_fraction"] * (equity - cost) / np.maximum(s, p), 0.0)
            transact(target, s, p, t, "daily_04_UTC_rebalance")
            perp_equity = equity * SPEC["perp_collateral_target_fraction"]
            assert float(np.sum(q * s)) <= equity * 0.4 + 1e-6
            assert float(np.sum(q * p)) <= equity * 0.4 + 1e-6
            assert equity - float(np.sum(q * s)) - perp_equity >= equity * 0.2 - 1e-6
            decisions.append({"decision_utc": d.isoformat(), "execution_utc": t.isoformat(),
                              "funding_window_end_exclusive": d.isoformat(), "mean_hourly_funding": signal["mean"].tolist(),
                              "projected_30_day_funding_fraction": projected.tolist(), "entry_hurdle_fraction": hurdle,
                              "prior_day_base_volumes_spot_perp": signal["volumes"].tolist(),
                              "volume_gate": liquid.tolist(), "prior_close_gap_bps": signal["gap_bps"].tolist(),
                              "active": active.tolist(), "target_q": target.tolist(), "post_trade_equity": equity})
        if t.hour == 23:
            block = t.floor("4h")
            s = np.array([CANDLES[(a, "spot")].loc[block, "c"] for a in ASSETS], dtype=float)
            p = np.array([CANDLES[(a, "perp")].loc[block, "c"] for a in ASSETS], dtype=float)
            mark(s, p)
            if t == HOURS[-1]:
                transact(np.zeros(2), s, p, END - pd.Timedelta(milliseconds=1), "terminal_close")
            assert abs(equity - (C0 + comp["spot_price_pnl"] + comp["perp_price_pnl"] + comp["funding"]
                                  - comp["fees"] - comp["execution"] - comp["financing_other"])) < 1e-6
            daily.append({"date": t.date().isoformat(), "equity": equity, **comp})
    df = pd.DataFrame(daily).set_index("date")
    df.index = pd.to_datetime(df.index, utc=True)
    result = {"version": version, "lookback_hours": lookback, "cost_buffer": cost_buffer,
              "daily": df, "components": comp, "trades": trades, "decisions": decisions,
              "settlements": settlements, "entries": dict(zip(ASSETS, entries.tolist())),
              "exits": dict(zip(ASSETS, exits.tolist())), "invested_hour_share": dict(zip(ASSETS, (invested_hours / len(HOURS)).tolist())),
              "minimum_4h_collateral_to_notional_PROXY": min_coverage,
              "proxy_stop_timestamp": stop_timestamp}
    return result


def performance(frame):
    nav = frame.equity
    r = nav.pct_change().dropna()
    vol = r.std(ddof=1)
    down = float(np.sqrt(np.mean(np.minimum(r, 0) ** 2)))
    dd = nav / nav.cummax() - 1
    trough = dd.idxmin()
    peak = nav.loc[:trough].idxmax()
    recovered = nav.loc[trough:][nav.loc[trough:] >= nav.loc[peak]]
    recovery = recovered.index[0] if len(recovered) else None
    return {"return": nav.iloc[-1] / nav.iloc[0] - 1,
            "volatility_ann": vol * np.sqrt(365),
            "sharpe_rf_zero": float(r.mean() / vol * np.sqrt(365)) if vol else None,
            "sortino_mar_zero": float(r.mean() / down * np.sqrt(365)) if down else None,
            "max_drawdown": float(dd.min()), "worst_day": float(r.min()),
            "worst_rolling_7d": float(nav.pct_change(7).min()),
            "max_dd_peak_date": peak, "max_dd_trough_date": trough, "max_dd_recovery_date": recovery,
            "recovery_days_from_trough": (recovery - trough).days if recovery is not None else None,
            "peak_to_recovery_days": (recovery - peak).days if recovery is not None else None,
            "unrecovered_days_after_trough": (nav.index[-1] - trough).days if recovery is None else 0,
            "observations": len(r)}


def describe(result):
    df, c = result["daily"], result["components"]
    holdout = df.loc[df.index >= HOLDOUT - pd.Timedelta(days=1)]
    preholdout = df.loc[df.index < HOLDOUT]
    gross = c["spot_price_pnl"] + c["perp_price_pnl"] + c["funding"]
    fees = c["fees"] + c["execution"] + c["financing_other"]
    trades = pd.DataFrame(result["trades"])
    trades["date"] = pd.to_datetime(trades.timestamp_utc, utc=True, format="ISO8601").dt.floor("D")
    vol = trades.groupby("date")[["spot_notional", "perp_notional"]].sum().reindex(DAYS, fill_value=0)
    weighted14 = (2 * vol.spot_notional + vol.perp_notional).rolling(14, min_periods=1).sum()
    return {"full_period": performance(df), "pre_holdout": performance(preholdout),
            "retrospective_holdout": performance(holdout), "components_usdc": c,
            "two_leg_price_pnl": c["spot_price_pnl"] + c["perp_price_pnl"],
            "gross_pnl": gross, "total_costs": fees, "net_pnl": gross - fees,
            "costs_as_fraction_of_gross_pnl": fees / gross if gross > 0 else None,
            "turnover_two_legs_over_average_equity": (c["spot_traded_notional"] + c["perp_traded_notional"]) / df.equity.iloc[1:].mean(),
            "maximum_model_14d_weighted_volume": weighted14.max(),
            "entries": result["entries"], "exits": result["exits"], "invested_hour_share": result["invested_hour_share"],
            "minimum_4h_collateral_to_notional_PROXY": result["minimum_4h_collateral_to_notional_PROXY"],
            "proxy_stop_timestamp": result["proxy_stop_timestamp"]}


def fixed_path_costs(result):
    c = result["components"]
    gross = c["spot_price_pnl"] + c["perp_price_pnl"] + c["funding"]
    notional = c["spot_traded_notional"] + c["perp_traded_notional"]
    records = []
    for fm in SPEC["cost_sensitivity"]["fee_multipliers"]:
        for eb in SPEC["cost_sensitivity"]["execution_bps"]:
            pnl = gross - c["fees"] * fm - notional * eb * 1e-4 - c["financing_other"]
            # Also recompute daily risk from the same fixed positions under the cost shock.
            d = result["daily"].copy()
            d["equity"] = C0 + d.spot_price_pnl + d.perp_price_pnl + d.funding - d.fees * fm - (d.spot_traded_notional + d.perp_traded_notional) * eb * 1e-4 - d.financing_other
            records.append({"fee_multiplier": fm, "execution_bps": eb, "return": pnl / C0,
                            "metrics_fixed_positions": performance(d)})
    return records


def setup_style():
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.labelcolor": NAVY,
                         "text.color": NAVY, "xtick.color": GREY, "ytick.color": GREY,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.edgecolor": "#D9E1E5", "axes.titleweight": "bold",
                         "savefig.facecolor": "white", "figure.facecolor": "white"})


def save_figure(fig, name):
    fig.savefig(OUT / f"{name}.png", dpi=220)
    fig.savefig(OUT / f"{name}.svg")
    plt.close(fig)


def figures(results, summaries, costs):
    setup_style()
    fig, ax = plt.subplots(2, 1, figsize=(13, 8), sharex=True, gridspec_kw={"height_ratios": [2.2, 1]})
    fig.subplots_adjust(left=.085, right=.97, bottom=.16, top=.84, hspace=.13)
    fig.suptitle("Funding carry: total-capital NAV and drawdown", x=.085, y=.963, ha="left", fontsize=19, fontweight="bold")
    fig.text(.085, .913, "CONDITIONAL MODEL  |  Price proxies + stated fee/execution assumptions", color=ORANGE, fontsize=11)
    fig.text(.085, .872, "Shaded region: retrospective holdout, May–Aug 2026", fontsize=9, color=GREY)
    for key, label, colour in (("passive", "Passive benchmark", NAVY), ("rule", "Rule-based", TEAL)):
        nav = results[key]["daily"].equity
        ax[0].plot(nav.index, nav / C0 * 100, color=colour, lw=2, label=f"{label}  {summaries[key]['full_period']['return']:+.2%}")
        ax[1].plot(nav.index, nav / nav.cummax() - 1, color=colour, lw=1.5)
    for a in ax:
        a.grid(axis="y", color="#E9EEF0")
        a.axvspan(HOLDOUT, END, color="#E7EDF1", alpha=.65, zorder=0)
    ax[0].legend(frameon=False, loc="upper left")
    ax[0].set_ylabel("Total allocated capital = 100")
    ax[1].set_ylabel("Drawdown")
    ax[1].yaxis.set_major_formatter(PercentFormatter(1, decimals=2))
    fig.text(.085, .070, "Source: Hyperliquid fundingHistory and spot/perpetual candles; author model. Sep 2025–Aug 2026.", fontsize=9, color=GREY)
    fig.text(.085, .045, "100,000 USDC allocated; USDC assumed equal to USD. Daily closes. Terminal exit costs included. Intrabar liquidation is not verified.", fontsize=9, color=GREY)
    save_figure(fig, "Figure_04_NAV_Drawdown")

    fig, axes = plt.subplots(1, 2, figsize=(15, 6.8), sharey=True)
    fig.subplots_adjust(left=.072, right=.98, bottom=.27, top=.79, wspace=.10)
    fig.suptitle("From gross PnL to net PnL", x=.072, y=.965, ha="left", fontsize=20, fontweight="bold")
    fig.text(.072, .913, "CONDITIONAL MODEL  |  Whole-period contribution in USDC", color=ORANGE, fontsize=11)
    labels = ["Two-leg\nprice PnL", "Net\nfunding", "Gross\nPnL", "Trading\nfees", "Execution\ncost", "Financing /\nother", "Net\nPnL"]
    for a, key in zip(axes, ("passive", "rule")):
        c, summ = results[key]["components"], summaries[key]
        values = [summ["two_leg_price_pnl"], c["funding"], summ["gross_pnl"], -c["fees"], -c["execution"], -c["financing_other"], summ["net_pnl"]]
        running = 0.0
        for i, v in enumerate(values):
            if i in (2, 6):
                bottom, height, colour = min(0, v), abs(v), NAVY if i == 2 else (TEAL if v >= 0 else ORANGE)
                running = v
            else:
                bottom, height, colour = min(running, running + v), abs(v), TEAL if v >= 0 else ORANGE
                running += v
            a.bar(i, height, bottom=bottom, width=.62, color=colour, zorder=3)
            value_label = "0" if abs(v) < .5 else (f"{v:+,.0f}" if i not in (2, 6) else f"{v:,.0f}")
            a.annotate(value_label, (i, bottom + height),
                       xytext=(0, 8), textcoords="offset points", ha="center", fontsize=10, fontweight="bold")
            if i < 6:
                a.plot([i + .32, i + .68], [running, running], color="#AAB8C0", lw=.8)
        a.set_xticks(range(7), labels, fontsize=9)
        a.set_title("Passive benchmark" if key == "passive" else "Rule-based", loc="left", pad=20, fontsize=13)
        a.axhline(0, color=GREY, lw=.6)
        a.grid(axis="y", color="#E9EEF0", zorder=0)
        a.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:,.0f}"))
    low = min(0, *(s["net_pnl"] for s in summaries.values()))
    high = max(s["gross_pnl"] for s in summaries.values())
    span = high - low
    axes[0].set_ylim(low - .12 * span, high + .16 * span)
    axes[0].set_ylabel("USDC")
    fig.text(.072, .11, "Two-leg price PnL includes both spot and perpetual price changes. Funding uses the latest completed 4h spot close as an oracle proxy.", fontsize=9, color=GREY)
    fig.text(.072, .075, "Trading fees: 7 bps spot / 4.5 bps perpetual, constant scenario. Execution: 2 bps per leg per trade; not also embedded in reference prices.", fontsize=9, color=GREY)
    fig.text(.072, .04, "Zero financing/other costs assumes fully funded capital, no bridge flow, no cash yield, and no additional service fees. Source: official API; author model.", fontsize=9, color=GREY)
    save_figure(fig, "Figure_05_Gross_to_Net")

    fig, axes = plt.subplots(1, 2, figsize=(13, 6.8), sharey=True)
    fig.subplots_adjust(left=.10, right=.97, bottom=.27, top=.79, wspace=.18)
    fig.suptitle("How much does execution cost change the result?", x=.10, y=.965, ha="left", fontsize=19, fontweight="bold")
    fig.text(.10, .913, "CONDITIONAL MODEL  |  Net return on all allocated capital; baseline positions held fixed", color=ORANGE, fontsize=11)
    matrices = {k: np.array([x["return"] for x in costs[k]]).reshape(3, 4) for k in costs}
    limit = max(abs(m).max() for m in matrices.values())
    from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
    cmap = LinearSegmentedColormap.from_list("cost", [ORANGE, "#F6F7F5", TEAL])
    for a, key in zip(axes, ("passive", "rule")):
        m = matrices[key]
        im = a.imshow(m, cmap=cmap, norm=TwoSlopeNorm(vmin=-limit, vcenter=0, vmax=limit), aspect="auto")
        for (i, j), v in np.ndenumerate(m):
            a.text(j, i, f"{v:+.2%}", ha="center", va="center", fontsize=13, fontweight="bold",
                   color="white" if abs(v) > .7 * limit else NAVY)
        a.set_xticks(range(4), [f"{x} bps" for x in SPEC["cost_sensitivity"]["execution_bps"]])
        a.set_yticks(range(3), [f"{x:g}×" for x in SPEC["cost_sensitivity"]["fee_multipliers"]])
        a.set_xlabel("Execution cost per leg per trade", labelpad=12)
        a.set_title("Passive benchmark" if key == "passive" else "Rule-based", loc="left", pad=20, fontsize=13)
        a.tick_params(length=0)
        for spine in a.spines.values():
            spine.set_visible(False)
    axes[0].set_ylabel("Multiplier on baseline trading fees", labelpad=12)
    fig.text(.10, .105, "1× fees = 7 bps spot and 4.5 bps perpetual. Each cell charges entry, rebalancing and terminal exit on both legs.", fontsize=9, color=GREY)
    fig.text(.10, .07, "Signals, units and gross cash flows are frozen for this diagnostic; no cost-specific signal selection or resizing. This is not a liquidity-capacity test.", fontsize=9, color=GREY)
    fig.text(.10, .035, "Source: Hyperliquid Info API and fee documentation retrieved September 2026; author scenario calculations.", fontsize=9, color=GREY)
    save_figure(fig, "Figure_06_Cost_Sensitivity")


def verify_independent_ledger(result):
    """Cash/inventory accounting, independent of the mark-to-market NAV recursion."""
    fills = result["trades"]
    spot_cash = sum(-r["delta_spot_q"] * r["spot_reference"] for r in fills)
    # With zero terminal positions, negative sum(delta_position * price) is realized perp PnL.
    perp_cash = sum(-r["delta_perp_q"] * r["perp_reference"] for r in fills)
    fund_cash = sum(sum(r["funding_cashflow_MODEL"]) for r in result["settlements"])
    costs = sum(r["fee"] + r["execution_cost"] for r in fills)
    terminal = C0 + spot_cash + perp_cash + fund_cash - costs
    error = terminal - result["daily"].equity.iloc[-1]
    assert abs(error) < 1e-6, (result["version"], error)
    assert all(all(abs(x) < 1e-12 for x in r["q_spot"]) for r in result["settlements"][:5])
    return {"terminal_cash_inventory_equity": terminal, "terminal_nav_equity": result["daily"].equity.iloc[-1],
            "difference": error, "spot_realized_pnl": spot_cash, "perp_realized_pnl": perp_cash,
            "funding_from_hourly_ledger": fund_cash, "trade_costs_from_ledger": costs,
            "entry_settlement_order_check": "First five hourly settlements have zero position; initial execution follows 04:00 settlement"}


def main():
    results = {key: simulate(key, retain=True) for key in ("passive", "rule")}
    summaries = {key: describe(result) for key, result in results.items()}
    costs = {key: fixed_path_costs(result) for key, result in results.items()}
    checks = {key: verify_independent_ledger(result) for key, result in results.items()}
    grid = []
    for w in SPEC["parameter_grid"]["lookback_hours"]:
        for b in SPEC["parameter_grid"]["entry_cost_buffer"]:
            r = results["rule"] if (w == SPEC["signal_lookback_hours"] and b == SPEC["entry_cost_buffer"]) else simulate("rule", lookback=w, cost_buffer=b)
            s = describe(r)
            grid.append({"lookback_hours": w, "entry_cost_buffer": b, "full_period": s["full_period"],
                         "retrospective_holdout": s["retrospective_holdout"], "entries": s["entries"],
                         "turnover": s["turnover_two_legs_over_average_equity"]})
    oracle_sensitivity = {}
    for key, r in results.items():
        # Conditional envelope only: assumes a uniform relative bound, not an observed oracle-price error.
        abs_cash = sum(sum(abs(v) for v in row["funding_cashflow_MODEL"]) for row in r["settlements"])
        oracle_sensitivity[key] = {"sum_absolute_model_funding_cashflows": abs_cash,
                                   "conditional_funding_error_if_oracle_within_1pct_of_proxy": .01 * abs_cash,
                                   "warning": "1% is an assumed bound; no historical oracle comparison has been verified."}
    for key, r in results.items():
        save_json(f"{key}_daily_nav.json", r["daily"].reset_index().rename(columns={"index": "date"}).to_dict("records"))
        save_json(f"{key}_trades.json", r["trades"])
        save_json(f"{key}_decisions.json", r["decisions"])
        save_json(f"{key}_hourly_funding_ledger.json", r["settlements"])
    save_json("performance_summary.json", summaries)
    save_json("accounting_checks.json", checks)
    save_json("cost_sensitivity_fixed_positions.json", costs)
    save_json("parameter_sensitivity.json", grid)
    save_json("oracle_proxy_conditional_sensitivity.json", oracle_sensitivity)
    figures(results, summaries, costs)
    print(json.dumps(plain({"summary": summaries, "parameter_grid_returns": [
        {"lookback": r["lookback_hours"], "buffer": r["entry_cost_buffer"], "return": r["full_period"]["return"],
         "holdout_return": r["retrospective_holdout"]["return"]} for r in grid], "accounting": checks}), indent=2))


if __name__ == "__main__":
    main()
