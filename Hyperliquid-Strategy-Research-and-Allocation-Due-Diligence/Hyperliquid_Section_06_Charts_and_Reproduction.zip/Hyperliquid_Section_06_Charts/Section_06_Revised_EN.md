# 6. Execution Costs & Capacity

Capacity requires an allocation to meet return, liquidation-time and collateral constraints under an executable policy. The available history supports conditional cost scenarios and turnover diagnostics; it does not establish an investable capital limit. Figures 6.1–6.3 therefore retain explicit model labels.

**Capital and execution assumptions.** The analysis covers September 2025–August 2026 and tests allocations from 25,000 to 10 million USDC. Each asset receives up to 20% of equity in spot, against an equal-unit perpetual short. Perpetual collateral and cash reserves account for another 40% and at least 20%, respectively. Returns use all initial capital.

Each trade incurs current undiscounted Tier-0 taker fees—7 bps for spot and 4.5 bps for perpetuals—plus a hypothetical 2 bps execution floor and size-dependent impact. These constant rates are scenarios; historical fee eligibility and discounts have not been reconstructed. Actual fees depend on rolling account turnover and applicable adjustments. [Official fee schedule](https://hyperliquid.gitbook.io/hyperliquid-docs/trading/fees)

The additional impact fraction is specified as:

\[
I=\eta\ln(H_{d-1}/L_{d-1})\sqrt{|\Delta q|/V_{d-1}}.
\]

Here, volume and price range refer to each leg's preceding complete UTC day. The central coefficient is 0.5, with 0.25 and 1.0 sensitivities. This function has not been calibrated to Hyperliquid fills; the shaded range is a scenario envelope, not a confidence interval. Costs are deducted separately from candle-reference PnL, without an additional adverse execution-price adjustment.

**Net return across allocations.** Figure 6.1 reruns each strategy at every allocation and impact coefficient. The rule's entry budget includes projected round-trip impact, so participation changes with size. At the central coefficient, passive full-year net return declines from 1.88% at 25,000 USDC to 1.83% at 100,000 and 0.98% at 10 million. The rule returns −0.49%, −1.56% and 0.00%, respectively. At 5 million and 10 million it opens no positions; zero return reflects assumed idle cash, not improved trading performance.

The replay retains idealized complete fills, a historical spot-price proxy for funding valuation, and frictionless collateral transfers. Its positive passive returns at larger sizes do not validate executable capacity. Intrabar mark-price and margin constraints remain unverified.

**Exit cost budgets and time.** Figure 6.2 estimates one standardized full exit across both assets and both legs. Day-start budgets use prior-day information and are grouped by the subsequent day's observed regime. Normal and stress samples contain 73 and 37 days. At 100,000 USDC, normal P50/P95 costs are 8.79/12.01 bps of all capital, versus 9.27/11.71 bps for stress. These are modeled budgets, not realized slippage; the lower stress P95 cannot establish cheaper stressed execution.

Figure 6.3 separately limits matched exit slices to 0.1% of each leg's historical four-hour base-unit volume. Joint completion requires both assets to finish. At 100,000 USDC, normal P50/P95 times are 44/84 hours, versus 20/44 hours for stress. At 500,000, 63.4% of normal and 22.2% of stress starts remain unfinished after seven days. All unfinished cases remain visible. Higher stress turnover can shorten this proxy without improving executable depth. The exit diagnostics are not additional charges against Figure 6.1 or a verified joint execution simulation.

**Allocation implications.** No tested central scenario clears the illustrative 2% annual return hurdle. Actual capacity remains unestablished rather than measured at zero. Priority bidding, if used, adds costs: IOC charges depend on filled notional, whereas ALO placement may incur charges without execution. [Official priority mechanics](https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/priority-fees) Maker inventory, queue competition and adverse selection require order-level evidence; these candle-based diagnostics cannot reproduce market-making performance.
