"""Reproduce three CONDITIONAL capacity diagnostics from archived official inputs.

Run: python3 build_capacity_charts.py
Requirements: Python 3, numpy, pandas, matplotlib. No network or trading calls.
"""
from pathlib import Path
import json
import math
import hashlib

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter, PercentFormatter

from section04_engine import CANDLES, ASSETS, DAYS, START, END, OBS, performance, plain
from capacity_engine import simulate, VOLUMES, RANGES

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
SPEC = json.loads((ROOT / "capacity_scenario_spec.json").read_text())
CAPITALS = SPEC["capital_grid_usdc"]
ETAS = SPEC["impact_eta_scenarios"]
CENTRAL = SPEC["impact_eta_central"]
CALENDAR = pd.DataFrame(json.loads((ROOT / "inputs/liquidity_regime_calendar.json").read_text()))
CALENDAR.index = pd.to_datetime(CALENDAR.date_utc, utc=True)
NAVY, TEAL, ORANGE, GREY = "#18334A", "#167F79", "#C56B3B", "#697982"


def save(name, obj):
    (OUT / name).write_text(json.dumps(plain(obj), indent=2, allow_nan=False) + "\n")


def short_cap(x, pos=None):
    return f"{x/1e6:g}m" if x >= 1e6 else f"{x/1e3:g}k"


def run_returns():
    checks, rows, daily = {}, [], []
    reference = json.loads((ROOT / "inputs/section04_reference_results.json").read_text())
    for version in ("passive", "rule"):
        baseline = simulate(version, capital=100000, eta=0)
        delta = performance(baseline["daily"])["return"] - reference[version]["full_period"]["return"]
        assert abs(delta) < 1e-10, (version, "Section 4 regression", delta)
        checks[version] = {"eta_zero_return_difference": delta, "passed": True}
    for capital in CAPITALS:
        for version in ("passive", "rule"):
            for eta in ETAS:
                r = simulate(version, capital=capital, eta=eta)
                stats, c = performance(r["daily"]), r["components"]
                assert math.isclose(c["execution"], c["execution_floor"] + c["impact"], rel_tol=1e-10)
                rows.append({"capital_usdc": capital, "version": version, "eta": eta,
                             "net_return": stats["return"], "max_drawdown": stats["max_drawdown"],
                             "net_pnl_usdc": r["daily"].equity.iloc[-1] - capital,
                             "average_asset_invested_hour_share": np.mean(list(r["invested_hour_share"].values())),
                             "invested_hour_share": r["invested_hour_share"],
                             "entries": r["entries"], "exits": r["exits"],
                             "components_usdc": c,
                             "minimum_collateral_coverage_PROXY": r["minimum_4h_collateral_to_notional_PROXY"],
                             "proxy_stop_timestamp": r["proxy_stop_timestamp"]})
                if eta == CENTRAL:
                    for t, z in r["daily"].iterrows():
                        daily.append({"capital_usdc": capital, "version": version,
                                      "date_utc": t, "equity_usdc": z.equity,
                                      "nav": z.equity / capital})
                    save(f"trades_{version}_{capital}_central.json", r["trades"])
                    save(f"decisions_{version}_{capital}_central.json", r["decisions"])
            print(f"Replayed {version}, capital {capital:,}", flush=True)
    save("return_scenarios.json", rows)
    save("central_daily_nav.json", daily)
    save("regression_checks.json", checks)
    return rows


def run_exit_costs():
    """One full exit; future trading volumes are not used to set this cost budget."""
    rows, summary = [], []
    for capital in CAPITALS:
        for day in DAYS:
            regime = CALENDAR.loc[day, "regime"]
            if regime not in ("normal", "stress"):
                continue
            s, p = OBS[day]["spot_proxy"], OBS[day]["perp_proxy"]
            q = 0.2 * capital / np.maximum(s, p)
            for eta in ETAS:
                imp = eta * RANGES[day] * np.sqrt(q[:, None] / VOLUMES[day])
                fees = q * (s * 7e-4 + p * 4.5e-4)
                floor = q * (s + p) * 2e-4
                impact = q * (s * imp[:, 0] + p * imp[:, 1])
                cost = float(np.sum(fees + floor + impact))
                rows.append({"capital_usdc": capital, "date_utc": day, "regime": regime, "eta": eta,
                             "exit_cost_usdc_MODEL": cost, "exit_cost_bps_all_capital_MODEL": cost / capital * 1e4,
                             "fees_usdc": fees.sum(), "execution_floor_usdc": floor.sum(),
                             "impact_usdc_MODEL": impact.sum(), "base_quantity_btc_eth": q.tolist(),
                             "spot_reference_btc_eth": s.tolist(), "perp_reference_btc_eth": p.tolist()})
        for regime in ("normal", "stress"):
            values = np.array([r["exit_cost_bps_all_capital_MODEL"] for r in rows
                               if r["capital_usdc"] == capital and r["regime"] == regime and r["eta"] == CENTRAL])
            summary.append({"capital_usdc": capital, "regime": regime, "n_days": len(values),
                            "p50_bps": np.quantile(values, 0.5, method="inverted_cdf"),
                            "p95_bps": np.quantile(values, 0.95, method="inverted_cdf")})
    save("exit_cost_daily_scenarios.json", rows)
    save("exit_cost_summary.json", summary)
    return summary


def censored_quantile(values, percentile):
    """Nearest-rank quantile; infinity means not completed within 168 hours."""
    values = sorted(values)
    value = values[max(0, math.ceil(percentile * len(values)) - 1)]
    return {"hours": value if math.isfinite(value) else None,
            "right_censored": not math.isfinite(value)}


def run_exit_times():
    rows, summary = [], []
    horizon = SPEC["exit_horizon_hours"]
    rho = SPEC["exit_participation_fraction"]
    for capital in CAPITALS:
        for day in DAYS:
            regime = CALENDAR.loc[day, "regime"]
            if regime not in ("normal", "stress") or day + pd.Timedelta(hours=horizon) > END:
                continue
            s, p = OBS[day]["spot_proxy"], OBS[day]["perp_proxy"]
            q = 0.2 * capital / np.maximum(s, p)
            remaining = q.copy()
            pair_hours = [math.inf, math.inf]
            independent_leg_hours = [[math.inf, math.inf], [math.inf, math.inf]]
            independent_volume = np.zeros((2, 2))
            remaining_24h = None
            for k in range(horizon // 4):
                t = day + pd.Timedelta(hours=4 * k)
                volume = np.array([[CANDLES[(asset, leg)].loc[t, "v"]
                                    for leg in ("spot", "perp")] for asset in ASSETS])
                assert volume.shape == (2, 2) and np.all(volume > 0)
                available = rho * volume
                slice_q = np.minimum(remaining, available.min(axis=1))
                remaining = np.maximum(0, remaining - slice_q)
                independent_volume += available
                for j in range(2):
                    if remaining[j] <= 1e-12 and not math.isfinite(pair_hours[j]):
                        pair_hours[j] = 4 * (k + 1)
                    for leg in range(2):
                        if independent_volume[j, leg] >= q[j] and not math.isfinite(independent_leg_hours[j][leg]):
                            independent_leg_hours[j][leg] = 4 * (k + 1)
                if k == 5:
                    remaining_24h = remaining.copy()
            joint = max(pair_hours)
            residual = float(np.sum(remaining * np.maximum(s, p)) / (0.4 * capital))
            residual24 = float(np.sum(remaining_24h * np.maximum(s, p)) / (0.4 * capital))
            assert 0 <= residual <= residual24 + 1e-12 <= 1 + 1e-12
            rows.append({"capital_usdc": capital, "date_utc": day, "regime": regime,
                         "joint_exit_hours_PROXY": joint if math.isfinite(joint) else None,
                         "right_censored_168h": not math.isfinite(joint),
                         "completed_within_24h_PROXY": joint <= 24,
                         "asset_pair_exit_hours_PROXY": pair_hours,
                         "independent_leg_volume_times_btc_eth_spot_perp_PROXY": independent_leg_hours,
                         "remaining_base_quantity_168h": remaining.tolist(),
                         "remaining_initial_inventory_fraction_24h": residual24,
                         "remaining_initial_inventory_fraction_168h": residual})
        for regime in ("normal", "stress"):
            group = [r for r in rows if r["capital_usdc"] == capital and r["regime"] == regime]
            times = [r["joint_exit_hours_PROXY"] if r["joint_exit_hours_PROXY"] is not None else math.inf for r in group]
            summary.append({"capital_usdc": capital, "regime": regime, "n_start_days": len(group),
                            "p50": censored_quantile(times, 0.5), "p95": censored_quantile(times, 0.95),
                            "completion_rate_24h": np.mean([t <= 24 for t in times]),
                            "right_censored_rate_168h": np.mean([not math.isfinite(t) for t in times]),
                            "median_remaining_inventory_fraction_168h": np.median([r["remaining_initial_inventory_fraction_168h"] for r in group])})
    # Monotonicity in capital is a structural check of the volume allocation logic.
    for regime in ("normal", "stress"):
        groups = [s for s in summary if s["regime"] == regime]
        assert np.all(np.diff([s["completion_rate_24h"] for s in groups]) <= 0)
        assert np.all(np.diff([s["right_censored_rate_168h"] for s in groups]) >= 0)
    save("exit_time_daily_proxy.json", rows)
    save("exit_time_summary.json", summary)
    return summary


def setup_style():
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                         "axes.labelcolor": NAVY, "text.color": NAVY,
                         "axes.edgecolor": "#C9D2D8", "xtick.color": GREY, "ytick.color": GREY,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "svg.fonttype": "none", "savefig.facecolor": "white"})


def frame(fig, number, title, subtitle, notes):
    fig.text(.075, .955, f"FIGURE 6.{number}  /  CONDITIONAL MODEL", color=TEAL, size=10, weight="bold")
    fig.text(.075, .916, title, color=NAVY, size=22, weight="bold")
    fig.text(.075, .877, subtitle, color=GREY, size=10.5)
    fig.text(.075, .071, notes, color=GREY, size=9, linespacing=1.6, va="top")


def capital_axis(ax):
    ax.set_xscale("log")
    ax.set_xticks(CAPITALS)
    ax.xaxis.set_major_formatter(FuncFormatter(short_cap))
    ax.minorticks_off()
    ax.set_xlim(CAPITALS[0] / 1.15, CAPITALS[-1] * 1.15)
    ax.grid(axis="y", color="#E8EDF0", lw=.8)
    ax.set_axisbelow(True)


def export(fig, filename):
    for ext in ("png", "svg"):
        fig.savefig(OUT / f"{filename}.{ext}", dpi=190)
    plt.close(fig)


def plot_returns(rows):
    df = pd.DataFrame(rows)
    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(12.8, 9.4), gridspec_kw={"height_ratios": [3, 1.35]})
    fig.subplots_adjust(left=.09, right=.97, top=.815, bottom=.18, hspace=.36)
    for version, label, color in (("passive", "Passive carry", TEAL), ("rule", "Rule-based carry", ORANGE)):
        subset = df[df.version == version]
        central = subset[subset.eta == CENTRAL].set_index("capital_usdc").loc[CAPITALS]
        lo = subset.groupby("capital_usdc").net_return.min().reindex(CAPITALS).values
        hi = subset.groupby("capital_usdc").net_return.max().reindex(CAPITALS).values
        ax.fill_between(CAPITALS, lo, hi, color=color, alpha=.13, linewidth=0)
        ax.plot(CAPITALS, central.net_return, "o-", color=color, lw=2.5, markersize=6, label=label)
        ax2.plot(CAPITALS, central.average_asset_invested_hour_share, "o-", color=color, lw=2)
    ax.axhline(.02, color=NAVY, linestyle=(0, (4, 3)), lw=1.2, label="Illustrative 2% hurdle")
    ax.axhline(0, color=GREY, lw=.7)
    ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=1))
    ax.set_ylabel("Full-year net return / all initial capital")
    ax.legend(loc="lower left", ncol=3, fontsize=10, frameon=False, bbox_to_anchor=(0, 1.025))
    ax2.yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
    ax2.set_ylim(-.07, 1.1)
    ax2.set_yticks([0, .5, 1])
    ax2.set_ylabel("Time invested\n(mean of BTC, ETH)")
    ax2.set_xlabel("Configured capital (USDC; logarithmic scale)")
    for a in (ax, ax2):
        capital_axis(a)
    ax2.annotate("Rule holds cash at 5m and 10m", xy=(5e6, 0), xytext=(2e5, .32),
                 fontsize=10, color=ORANGE, arrowprops={"arrowstyle": "-", "color": ORANGE})
    frame(fig, 1, "More capital changes costs and participation",
          "BTC / UBTC and ETH / UETH  |  1 Sep 2025–31 Aug 2026 UTC  |  Policy rerun at every capital level",
          "Historical funding and candle references; idealized full fills and collateral transfers. Lines: impact eta = 0.5;\n"
          "shading: eta = 0.25–1.0 scenarios, not confidence intervals. Fixed current Tier-0 fees; no verified executable capacity.\n"
          "Source: Hyperliquid official candleSnapshot and fundingHistory responses; author calculations.")
    export(fig, "Figure_6_1_Capital_Net_Return")


def plot_exit_costs(rows):
    fig, ax = plt.subplots(figsize=(12.8, 8.5))
    fig.subplots_adjust(left=.09, right=.97, top=.79, bottom=.2)
    for regime, color in (("normal", TEAL), ("stress", ORANGE)):
        g = [r for r in rows if r["regime"] == regime]
        for key, quantile, style, marker in (("p50_bps", "P50", "-", "o"), ("p95_bps", "P95", "--", "D")):
            ax.plot(CAPITALS, [r[key] for r in g], linestyle=style, marker=marker, lw=2.4,
                    color=color, label=f"{regime.title()} {quantile}")
    ax.set_xlabel("Configured capital (USDC; logarithmic scale)")
    ax.set_ylabel("One full exit: cost in bps of all configured capital")
    ax.set_ylim(bottom=0)
    capital_axis(ax)
    ax.legend(loc="lower left", bbox_to_anchor=(0, 1.025), frameon=False, ncol=4, fontsize=10)
    frame(fig, 2, "Full-exit cost budgets increase with order size",
          "1 Sep 2025–31 Aug 2026 UTC  |  Normal 73 / stress 37 days  |  Central impact assumption: eta = 0.5",
          "One standardized exit of both assets and both legs; 40% total spot allocation with matching short perps.\n"
          "Fees + 2 bps execution floor per leg + hypothetical impact from prior-day range and volume. Not measured slippage.\n"
          "Source: Hyperliquid official candleSnapshot responses; day-start budgets grouped by the subsequent day's regime.")
    export(fig, "Figure_6_2_Normal_Stress_Exit_Cost")


def plot_exit_times(rows):
    fig, (ax, table_ax) = plt.subplots(2, 1, figsize=(12.8, 9.4), gridspec_kw={"height_ratios": [3.4, 1]})
    fig.subplots_adjust(left=.09, right=.97, top=.80, bottom=.17, hspace=.23)
    for regime, color in (("normal", TEAL), ("stress", ORANGE)):
        g = [r for r in rows if r["regime"] == regime]
        for key, style, marker in (("p50", "-", "o"), ("p95", "--", "D")):
            values = [r[key]["hours"] if not r[key]["right_censored"] else np.nan for r in g]
            ax.plot(CAPITALS, values, linestyle=style, marker=marker, lw=2.3, color=color,
                    label=f"{regime.title()} {key.upper()}")
            mask = np.array([r[key]["right_censored"] for r in g])
            if mask.any():
                # The top band is a categorical censoring strip, not a measured 192-hour observation.
                strip_y = {("normal", "p50"): 187, ("normal", "p95"): 192,
                           ("stress", "p50"): 197, ("stress", "p95"): 202}[(regime, key)]
                ax.scatter(np.array(CAPITALS)[mask], np.full(mask.sum(), strip_y),
                           marker=marker, edgecolor=color, facecolor="white", s=40, linewidth=1.5, zorder=5)
    ax.axhspan(180, 207, color="#F4F0EB", zorder=0)
    ax.axhline(24, color=NAVY, linestyle=(0, (3, 3)), linewidth=1)
    ax.set_yticks([4, 24, 48, 96, 144, 168, 192], ["4", "24", "48", "96", "144", "168", ">168"])
    ax.set_ylim(0, 207)
    ax.set_ylabel("Joint exit-time proxy (hours; 4-hour steps)")
    ax.set_xlabel("Configured capital (USDC; logarithmic scale)")
    capital_axis(ax)
    ax.legend(loc="lower left", bbox_to_anchor=(0, 1.025), frameon=False, ncol=4, fontsize=10)
    table_ax.axis("off")
    table_data, row_labels = [], []
    for regime in ("normal", "stress"):
        g = [r for r in rows if r["regime"] == regime]
        table_data.append([f"{r['completion_rate_24h']:.0%}" for r in g])
        row_labels.append(f"{regime.title()}: complete within 24h")
    for regime in ("normal", "stress"):
        g = [r for r in rows if r["regime"] == regime]
        table_data.append([f"{r['right_censored_rate_168h']:.0%}" for r in g])
        row_labels.append(f"{regime.title()}: unfinished at 168h")
    tab = table_ax.table(cellText=[[label]+row for label, row in zip(row_labels, table_data)],
                         colLabels=["Volume-proxy completion", *[short_cap(k) for k in CAPITALS]],
                         colWidths=[.39, *([.61/6]*6)], cellLoc="center", bbox=[0, 0, 1, 1])
    tab.auto_set_font_size(False)
    tab.set_fontsize(9.6)
    for (row, col), cell in tab.get_celld().items():
        cell.set_edgecolor("#E8EDF0")
        if row == 0:
            cell.set_facecolor("#EEF3F5")
            cell.set_text_props(weight="bold", color=NAVY)
        if col == 0:
            cell.set_text_props(ha="left")
    n_normal = next(r["n_start_days"] for r in rows if r["regime"] == "normal")
    n_stress = next(r["n_start_days"] for r in rows if r["regime"] == "stress")
    frame(fig, 3, "Volume limits can stretch an exit across days",
          f"1 Sep 2025–25 Aug 2026 UTC starts  |  0.1% participation per leg  |  Normal {n_normal} / stress {n_stress} start days",
          "Slices use the smaller spot/perp base-unit volume; both assets must finish. >168h includes every unfinished exit.\n"
          "Historical turnover is not executable depth. Stress volume can rise; shorter proxy times do not imply safer execution.\n"
          "Source: Hyperliquid official candleSnapshot responses; 00:00 UTC starts with a complete seven-day observation window.")
    export(fig, "Figure_6_3_Normal_Stress_Exit_Time")


def main():
    OUT.mkdir(exist_ok=True)
    setup_style()
    returns = run_returns()
    cost = run_exit_costs()
    times = run_exit_times()
    plot_returns(returns)
    plot_exit_costs(cost)
    plot_exit_times(times)
    save("input_sha256.json", {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in sorted((ROOT / "inputs").glob("*.json"))})
    print(json.dumps(plain({"central_returns": [r for r in returns if r["eta"] == CENTRAL],
                           "exit_cost": cost, "exit_time": times}), indent=2))


if __name__ == "__main__":
    main()
