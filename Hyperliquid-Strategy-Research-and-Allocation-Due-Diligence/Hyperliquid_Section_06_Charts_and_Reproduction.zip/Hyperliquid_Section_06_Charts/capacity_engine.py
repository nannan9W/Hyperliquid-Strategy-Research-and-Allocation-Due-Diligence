"""Conditional size-sensitive extension of the Section 4 engine.

Historical funding and candle data; idealized complete fills, explicit impact
stress function. Not an execution-validated strategy or deployable capacity.
"""
from section04_engine import (SPEC, START, END, DAYS, HOURS, ASSETS, OBS,
                              CANDLES, FUNDING, pd, np, math)

VOLUMES, RANGES = {}, {}
for day in DAYS:
    VOLUMES[day], RANGES[day] = np.zeros((2, 2)), np.zeros((2, 2))
    for j, asset in enumerate(ASSETS):
        for k, leg in enumerate(("spot", "perp")):
            bars = CANDLES[(asset, leg)].loc[day - pd.Timedelta(days=1):day - pd.Timedelta(hours=4)]
            assert len(bars) == 6
            VOLUMES[day][j, k] = bars.v.sum()
            RANGES[day][j, k] = np.log(bars.h.max() / bars.l.min())

def simulate(version, capital=100000, eta=0.5, lookback=None, cost_buffer=None, fee_multiplier=1.0, execution_bps=None, retain=False):
    C0 = float(capital)
    lookback = lookback or SPEC["signal_lookback_hours"]
    cost_buffer = cost_buffer if cost_buffer is not None else SPEC["entry_cost_buffer"]
    execution_bps = execution_bps if execution_bps is not None else SPEC["execution_bps_per_leg_per_trade"]
    sf = SPEC["spot_fee_bps"] * 1e-4 * fee_multiplier
    pf = SPEC["perp_fee_bps"] * 1e-4 * fee_multiplier
    ec = execution_bps * 1e-4
    base_hurdle = cost_buffer * (2 * (sf + pf) + 4 * ec)
    q = np.zeros(2)
    equity = float(C0)
    perp_equity = C0 * SPEC["perp_collateral_target_fraction"]
    last_s, last_p = OBS[START]["spot_proxy"].copy(), OBS[START]["perp_proxy"].copy()
    comp = {"spot_price_pnl": 0.0, "perp_price_pnl": 0.0, "funding": 0.0,
            "fees": 0.0, "execution": 0.0, "financing_other": 0.0,
            "spot_traded_notional": 0.0, "perp_traded_notional": 0.0, "execution_floor": 0.0, "impact": 0.0}
    trades, settlements = [], []
    decisions = []
    daily = [{"date": (START - pd.Timedelta(days=1)).date().isoformat(), "equity": equity, **comp}]
    stopped, min_coverage = False, math.inf
    stop_timestamp = None
    entries, exits = np.zeros(2, dtype=int), np.zeros(2, dtype=int)
    invested_hours = np.zeros(2, dtype=int)
    signals = {}
    for d in DAYS:
        lo = d - pd.Timedelta(hours=lookback)
        rates = np.array([FUNDING[a].loc[(FUNDING[a].index >= lo) & (FUNDING[a].index < d)].mean()
                          for a in ASSETS])
        assert all(len(FUNDING[a].loc[(FUNDING[a].index >= lo) & (FUNDING[a].index < d)]) == lookback
                   for a in ASSETS)
        vols = np.array([[CANDLES[(a, leg)].loc[(CANDLES[(a, leg)].index >= d - pd.Timedelta(days=1)) &
                         (CANDLES[(a, leg)].index < d), "v"].sum() for leg in ("spot", "perp")]
                         for a in ASSETS])
        s, p = OBS[d]["spot_proxy"], OBS[d]["perp_proxy"]
        gap = np.abs(p / s - 1) * 1e4
        signals[d] = {"mean": rates, "volumes": vols, "gap_bps": gap}

    def cost_parts(delta, s, p, day):
        qty = np.abs(delta)
        imp = eta * RANGES[day] * np.sqrt(qty[:, None] / VOLUMES[day])
        fees = qty * (s * sf + p * pf)
        floor = qty * (s + p) * ec
        impact = qty * (s * imp[:, 0] + p * imp[:, 1])
        perp_cost = qty * p * (pf + ec + imp[:, 1])
        return fees, floor, impact, perp_cost

    def mark(s, p):
        nonlocal equity, perp_equity, last_s, last_p
        spot_pnl = float(np.sum(q * (s - last_s)))
        perp_pnl = float(np.sum(-q * (p - last_p)))
        equity += spot_pnl + perp_pnl
        perp_equity += perp_pnl
        comp["spot_price_pnl"] += spot_pnl
        comp["perp_price_pnl"] += perp_pnl
        last_s, last_p = s.copy(), p.copy()

    def transact(target, s, p, timestamp, reason):
        nonlocal equity, perp_equity, q
        delta = target - q
        fees, floor, impact, perp_cost = cost_parts(delta, s, p, timestamp.floor("D"))
        execution = floor + impact
        equity -= float(np.sum(fees + execution))
        perp_equity -= float(perp_cost.sum())
        comp["fees"] += float(fees.sum())
        comp["execution"] += float(execution.sum())
        comp["execution_floor"] += float(floor.sum())
        comp["impact"] += float(impact.sum())
        comp["spot_traded_notional"] += float(np.sum(np.abs(delta) * s))
        comp["perp_traded_notional"] += float(np.sum(np.abs(delta) * p))
        for j, a in enumerate(ASSETS):
            if q[j] <= 1e-12 < target[j]:
                entries[j] += 1
            if target[j] <= 1e-12 < q[j]:
                exits[j] += 1
            if abs(delta[j]) > 1e-12:
                trades.append({"timestamp_utc": timestamp.isoformat(), "asset": a, "reason": reason,
                               "old_q": q[j], "new_q": target[j], "delta_spot_q": delta[j],
                               "delta_perp_q": -delta[j], "spot_reference": s[j], "perp_reference": p[j],
                               "spot_notional": abs(delta[j]) * s[j], "perp_notional": abs(delta[j]) * p[j],
                               "fee": fees[j], "execution_cost": execution[j],
                               "execution_floor": floor[j], "impact_cost_MODEL": impact[j]})
        q = target.copy()

    for t in HOURS:
        ob = OBS[t]
        if t.hour % 4 == 0:
            mark(ob["spot_proxy"], ob["perp_proxy"])
        # Settle BEFORE any position change at this hour. Proxy is explicitly not oraclePx.
        fund = q * ob["spot_proxy"] * ob["rates"]
        equity += float(fund.sum())
        perp_equity += float(fund.sum())
        comp["funding"] += float(fund.sum())
        invested_hours += (q > 1e-12).astype(int)
        if retain:
            settlements.append({"hour_utc": t.isoformat(), "q_spot": q.tolist(), "q_perp": (-q).tolist(),
                                "hourly_rate": ob["rates"].tolist(),
                                "oracle_PROXY_prior_4h_spot_close": ob["spot_proxy"].tolist(),
                                "funding_cashflow_MODEL": fund.tolist()})
        if t.hour % 4 == 0:
            notional = float(np.sum(q * ob["perp_proxy"]))
            coverage = perp_equity / notional if notional > 0 else math.inf
            min_coverage = min(min_coverage, coverage)
            breach = coverage < SPEC["common_proxy_collateral_coverage_stop"]
            if breach and not stopped:
                stopped, stop_timestamp = True, t
                mark(ob["spot_open"], ob["perp_open"])
                transact(np.zeros(2), ob["spot_open"], ob["perp_open"], t, "common_proxy_collateral_stop")
        if t.hour == SPEC["execution_hour_utc"]:
            s, p = ob["spot_open"], ob["perp_open"]
            mark(s, p)
            d = t.floor("D")
            signal = signals[d]
            full_q = SPEC["spot_target_per_asset_fraction"] * equity / np.maximum(s, p)
            projected = signal["mean"] * SPEC["carry_projection_days"] * 24
            entry_impact = eta * RANGES[d] * np.sqrt(full_q[:, None] / VOLUMES[d])
            hurdle = base_hurdle + cost_buffer * 2 * entry_impact.sum(axis=1)
            liquid = (full_q[:, None] <= SPEC["rule_max_position_prior_day_base_volume_fraction"] * signal["volumes"]).all(axis=1)
            basis_ok = signal["gap_bps"] < SPEC["rule_max_absolute_close_price_gap_bps"]
            if version == "passive":
                active = np.ones(2, dtype=bool)
            else:
                active = np.where(q > 1e-12, signal["mean"] > SPEC["exit_funding_mean_threshold"], projected > hurdle)
                active = active & liquid & basis_ok
            if stopped:
                active[:] = False
            # Solve weights against post-cost equity; no borrowed capital or external inflow.
            target = np.where(active, full_q, 0.0)
            for _ in range(12):
                delta = np.abs(target - q)
                fees, floor, impact, _ = cost_parts(delta, s, p, d)
                cost = float(np.sum(fees + floor + impact))
                assert cost < equity, "Cost scenario exhausts capital"
                target = np.where(active, SPEC["spot_target_per_asset_fraction"] * (equity - cost) / np.maximum(s, p), 0.0)
            transact(target, s, p, t, "daily_04_UTC_rebalance")
            perp_equity = equity * SPEC["perp_collateral_target_fraction"]
            assert float(np.sum(q * s)) <= equity * 0.4 + 1e-6
            assert float(np.sum(q * p)) <= equity * 0.4 + 1e-6
            assert equity - float(np.sum(q * s)) - perp_equity >= equity * 0.2 - 1e-6
            decisions.append({"decision_utc": d.isoformat(), "execution_utc": t.isoformat(),
                              "funding_window_end_exclusive": d.isoformat(), "mean_hourly_funding": signal["mean"].tolist(),
                              "projected_30_day_funding_fraction": projected.tolist(), "entry_hurdle_fraction": hurdle.tolist(),
                              "prior_day_base_volumes_spot_perp": signal["volumes"].tolist(),
                              "volume_gate": liquid.tolist(), "prior_close_gap_bps": signal["gap_bps"].tolist(),
                              "active": active.tolist(), "target_q": target.tolist(), "post_trade_equity": equity})
        if t.hour == 23:
            block = t.floor("4h")
            s = np.array([CANDLES[(a, "spot")].loc[block, "c"] for a in ASSETS], dtype=float)
            p = np.array([CANDLES[(a, "perp")].loc[block, "c"] for a in ASSETS], dtype=float)
            mark(s, p)
            if t == HOURS[-1]:
                transact(np.zeros(2), s, p, END - pd.Timedelta(milliseconds=1), "terminal_close")
            assert abs(equity - (C0 + comp["spot_price_pnl"] + comp["perp_price_pnl"] + comp["funding"]
                                  - comp["fees"] - comp["execution"] - comp["financing_other"])) < 1e-6
            daily.append({"date": t.date().isoformat(), "equity": equity, **comp})
    df = pd.DataFrame(daily).set_index("date")
    df.index = pd.to_datetime(df.index, utc=True)
    result = {"version": version, "lookback_hours": lookback, "cost_buffer": cost_buffer,
              "daily": df, "components": comp, "trades": trades, "decisions": decisions,
              "settlements": settlements, "entries": dict(zip(ASSETS, entries.tolist())),
              "exits": dict(zip(ASSETS, exits.tolist())), "invested_hour_share": dict(zip(ASSETS, (invested_hours / len(HOURS)).tolist())),
              "minimum_4h_collateral_to_notional_PROXY": min_coverage,
              "initial_configured_capital": C0, "impact_eta": eta,
              "proxy_stop_timestamp": stop_timestamp}
    return result

