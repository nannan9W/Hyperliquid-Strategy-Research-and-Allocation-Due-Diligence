"""Read-only public Hyperliquid data retrieval. No credentials or trading calls."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
import shutil
import urllib.request

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"
INPUTS.mkdir(parents=True, exist_ok=True)
SOURCE = ROOT.parent / "section02_work"
URL = "https://api.hyperliquid.xyz/info"

def stamp(s):
    return int(datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp() * 1000)

START = stamp("2025-08-25T00:00:00Z")
PERIOD_START = stamp("2025-09-01T00:00:00Z")
END = stamp("2026-09-01T00:00:00Z")

def fetch(job):
    filename, payload = job
    req = urllib.request.Request(URL, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=40) as response:
        data = json.load(response)
    result = {"endpoint": URL, "request": payload,
              "retrieved_at": datetime.now(timezone.utc).isoformat(), "response": data}
    (INPUTS / filename).write_text(json.dumps(result, indent=2) + "\n")
    return {"file": filename, "rows": len(data), "retrieved_at": result["retrieved_at"]}

def main():
    for asset in ("btc", "eth"):
        for suffix in ("funding_hourly", "perp_daily", "spot_daily"):
            filename = f"{asset}_{suffix}.json"
            if not (INPUTS / filename).exists():
                shutil.copy2(SOURCE / filename, INPUTS / filename)
    if not (INPUTS / "instrument_mapping_snapshot.json").exists():
        shutil.copy2(SOURCE / "instrument_mapping_snapshot.json", INPUTS / "instrument_mapping_snapshot.json")
    jobs = []
    for asset, spot in (("btc", "@142"), ("eth", "@151")):
        for leg, coin in (("spot", spot), ("perp", asset.upper())):
            jobs.append((f"{asset}_{leg}_4h.json", {"type": "candleSnapshot", "req": {
                "coin": coin, "interval": "4h", "startTime": START, "endTime": END - 1}}))
        jobs.append((f"{asset}_funding_warmup.json", {"type": "fundingHistory", "coin": asset.upper(),
                                                  "startTime": START, "endTime": PERIOD_START - 1}))
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(fetch, jobs))
    (ROOT / "retrieval_audit.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    main()
