# Hyperliquid report — Section 4 reproducibility package

**Status: conditional model, not a verified executable backtest.**

The package contains the English manuscript, Chinese author notes, source API
responses, fixed model specification, full settlement/trade/NAV ledgers, metrics,
parameter and cost sensitivities, diagnostic attribution, and three publication
figures in PNG and SVG. No Dune data are used.

The main English draft contains approximately 815 words including its tables and
captions; the Chinese work notes are outside the intended 3,000–4,000-word report.

## Main result under stated assumptions

| Total-capital return | Passive | Original rule |
|---|---:|---:|
| September 2025–August 2026 | +1.9252% | −1.8263% |
| Retrospective holdout, May–August 2026 | +0.7496% | −0.8406% |

These estimates use actual hourly funding rates but **not actual historical
settlement oracle prices**. The oracle proxy is the latest completed four-hour
spot-candle close. Fees use a constant scenario based on current undiscounted
Tier-0 rates retrieved 10 September 2026; historical effective fees and account
eligibility have not been reconstructed. Trade prices and execution costs are
reference assumptions, not filled orders. No intrabar liquidation or capacity
validation has been performed.

The rule combines funding and risk/volume screens. Its original result is retained.
After observing the result, one diagnostic removes the volume gate and produces
+0.8051% full-period return. This is explicitly a post-result ablation, not a
replacement strategy, parameter optimization or new untouched out-of-sample result.

## Reproduce offline

From this directory, with Python 3 and numpy, pandas, matplotlib installed:

```bash
python3 build_section04.py
python3 diagnose_rule.py
```

No credentials, network requests or trading operations are used by these commands.
The first script rebuilds outputs and all three figures. The second produces exit
attribution and the separately labelled post-result diagnostic. It changes a
parameter only in its process memory; model_spec.json is not altered.

`fetch_additional_inputs.py` documents the read-only public API collection for
four-hour candles and funding warmup. Running it requires network access and may
overwrite the additional-input responses with fresh requests. It does not refresh
the original year of funding or daily candles. The live API retains only the most
recent 5,000 candles per interval, so future online reconstruction of this fixed
historical window is not guaranteed. Preserve the packaged responses.

## Input audit

- Window: 2025-09-01 00:00 UTC inclusive to 2026-09-01 00:00 UTC exclusive.
- BTC and ETH: 8,760 hourly funding observations each, retrieved 9 September 2026.
- Four legs: BTC perp, UBTC/USDC spot, ETH perp, UETH/USDC spot.
- Each leg has 365 daily candles and 2,190 four-hour candles in the main period.
- Additional price/funding warmup starts 25 August 2025; each four-hour input has
  2,232 rows, and each separate funding warmup has 168 rows.
- Four-hour data and warmup were retrieved 10 September 2026. Exact times are
  embedded in responses and retrieval_audit.json.
- Four-hour OHLC aggregates match original daily OHLC exactly. Base-unit volume
  aggregates match within floating-point tolerance. No missing/duplicate grid
  slots or nonfinite observations passed validation.
- Current spot/perp mappings are preserved as a snapshot; they do not establish
  historical token-redemption or margin conditions.

## Outputs

| File | Purpose |
|---|---|
| Hyperliquid_Report_Section_04.md | English report section and Chinese author/data notes |
| model_spec.json | Fixed baseline assumptions and sensitivity grid |
| outputs/data_validation.json | Coverage and daily/four-hour consistency |
| outputs/performance_summary.json | Full, pre-holdout and retrospective-holdout metrics |
| outputs/passive_daily_nav.json, rule_daily_nav.json | Daily total-capital NAV and cumulative PnL components |
| outputs/*_hourly_funding_ledger.json | Position, hourly funding rate, oracle proxy and model cash flow |
| outputs/*_trades.json | Both legs, reference prices, quantities, fees and execution costs |
| outputs/*_decisions.json | Signal cutoff, trailing mean, gates and target positions |
| outputs/accounting_checks.json | Independent cash/inventory and NAV reconciliation |
| outputs/parameter_sensitivity.json | All nine predetermined parameter combinations |
| outputs/cost_sensitivity_fixed_positions.json | Fees/execution shocks with baseline positions frozen |
| outputs/rule_diagnostics.json | Exit reasons, holding periods and post-result ablation |
| outputs/oracle_proxy_conditional_sensitivity.json | An assumed 1% relative oracle-error envelope, not an observed error bound |
| outputs/Figure_04_NAV_Drawdown.png/.svg | Full-capital NAV and daily drawdown |
| outputs/Figure_05_Gross_to_Net.png/.svg | PnL reconciliation waterfall |
| outputs/Figure_06_Cost_Sensitivity.png/.svg | Net-return cost matrix |
| MANIFEST.json | SHA-256 and size for packaged files, except the manifest itself |

Core model accounting has two independent checks: daily NAV equals cumulative
component PnL; final flat-portfolio cash equals spot/perp trade cash plus hourly
funding less costs. Terminal differences are below 0.000001 USDC. The initial five
settlements (00:00 through 04:00) have zero positions, and terminal closing fees
are charged. These checks validate accounting arithmetic, not executability.

## Sources and missing data

- [Hyperliquid funding](https://hyperliquid.gitbook.io/hyperliquid-docs/trading/funding)
- [Hyperliquid fees](https://hyperliquid.gitbook.io/hyperliquid-docs/trading/fees)
- [Hyperliquid margining](https://hyperliquid.gitbook.io/hyperliquid-docs/trading/margining)
- [Hyperliquid Info API](https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/info-endpoint)
- [Historical archives](https://hyperliquid.gitbook.io/hyperliquid-docs/historical-data)

The author notes list the exact remaining datasets and an archive-download
example. An earlier anonymous archive access probe returned 403; that is not
evidence that the requested object or all historical data are missing. Official
archive transfer can require the requester's AWS configuration and payment.
No AWS credentials were sought or used.

Keep **CONDITIONAL MODEL** on figures until historical oracle/mark prices,
synchronized executable books, effective fee schedules and margin/event paths are
reconciled. Messari's HYPE aggregate derivatives charts cannot establish these
custom BTC/ETH strategy cash flows.
