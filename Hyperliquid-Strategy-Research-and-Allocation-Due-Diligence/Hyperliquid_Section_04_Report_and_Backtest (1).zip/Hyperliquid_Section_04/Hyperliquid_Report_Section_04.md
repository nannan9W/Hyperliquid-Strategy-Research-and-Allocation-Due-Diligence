# 4. Funding Carry: Construction & Net Performance

A conditional replay over **1 September 2025–31 August 2026** produces a **+1.93%** total-capital return for passive carry and **−1.83%** for the specified trading rule. These are model estimates using observed funding rates and candle prices. Historical settlement oracle prices, executable books and dated fee schedules remain unverified; the results therefore require execution validation before investment use.

The portfolio starts with **100,000 USDC**, assumed equal to USD, and pairs UBTC/UETH spot with equal-unit BTC/ETH perpetual shorts. At each daily rebalance, each asset receives up to 20% of total equity per leg, sized using the higher reference price. Perpetual collateral is separately allocated 40%; at least 20% remains as a cash buffer. Inactive allocations earn zero. Returns include all capital, without counting spot inventory again as collateral.

| Design choice | Fixed specification |
|---|---|
| Passive benchmark | Maintain both hedges; rebalance daily at 04:00 UTC, accepting either funding sign. |
| Information timing | Decide at 00:00 using the preceding 72 completed hourly funding observations; execute after the 04:00 settlement. |
| Rule entry | Project the trailing mean over 30 days; enter when projected funding exceeds 1.5 times estimated round-trip costs. This is a persistence assumption. |
| Liquidity screen | Require the entire target quantity to be ≤0.1% of the previous UTC day’s base-unit volume on each leg. |
| Price-risk screen | Require the absolute previous-close spot/perpetual price gap to be below 100 bps. |
| Rule exit | Close when the trailing funding mean becomes nonpositive or either screen fails; otherwise rebalance. Re-entry requires the entry hurdle again. |
| Common controls | Close permanently if the four-hour collateral/notional proxy falls below 50%; charge terminal closing costs to both portfolios. |

Positions are equal in underlying units, rather than merely equal dollar amounts. Summing intervals with unchanged positions, net PnL is:

\[
\Pi=\sum_{i,k}q_{i,k}(\Delta S_{i,k}-\Delta P_{i,k})
+\sum_{i,h}q_{i,h^-}O_{i,h}f_{i,h}-F-X-B.
\]

Here, \(S\) and \(P\) are spot and perpetual reference prices; \(q\) is the positive hedged quantity; \(O\) is the settlement oracle price; and \(F,X,B\) denote fees, additional execution costs, and financing/other costs. Positive funding benefits the short. Hyperliquid settles hourly using the position and **oracle price**, not mark price. [Official funding methodology](https://hyperliquid.gitbook.io/hyperliquid-docs/trading/funding)

For this provisional replay, the latest completed four-hour spot close substitutes for \(O\). Settlement precedes each trade, preventing new positions from receiving an already-settled payment. Candle opens provide trade references; terminal exits use final closes. Neither constitutes verified fills.

The cost scenario applies **7 bps spot / 4.5 bps perpetual** taker fees, plus **2 bps per leg per trade**. These are current undiscounted Tier-0 rates observed on 10 September 2026, not reconstructed historical rates. Model weighted 14-day turnover remains below $0.60 million; no higher tier is assumed. [Official fee schedule](https://hyperliquid.gitbook.io/hyperliquid-docs/trading/fees)

The round-trip cost budget is approximately **31 bps of matched one-leg notional**, making the 30-day entry hurdle **46.5 bps**. Execution costs are deducted separately from reference-price PnL; actual fill-based accounting must avoid deducting embedded slippage again. Borrowing, cash yield, bridge flows and additional service fees are zero by assumption.

| Conditional model metric | Passive | Rule-based |
|---|---:|---:|
| Cumulative net return | +1.93% | −1.83% |
| Annualized daily volatility | 0.37% | 0.36% |
| Sharpe / Sortino | 5.19 / 8.73 | −5.14 / −5.74 |
| Maximum daily-close drawdown | −0.10% | −2.19% |
| Worst day / rolling seven days | −0.08% / −0.07% | −0.08% / −0.19% |
| Recovery from maximum-drawdown trough | 19 days | Unrecovered at cutoff |
| Two-leg turnover / average equity | 7.09× | 42.74× |
| Costs / positive gross PnL | 22.4% | 224.6% |
| May–August cumulative net return | +0.75% | −0.84% |

Daily simple returns use total equity; volatility and ratios annualize with 365 days. Sharpe uses a zero cash hurdle; Sortino uses a zero target and downside deviation across all days. These assumptions require separate cash-opportunity-cost assessment. Source: [official API data](https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api/info-endpoint) and author model.

Passive gross PnL of **2,480 USDC** falls to **1,925** after costs. The rule generates **1,465** gross but incurs **3,292** in costs. Its liquidity threshold causes **41 of 50 nonterminal exits**; median holding spells are only four days for BTC and two for ETH, undermining the 30-day cost-payback assumption. A subsequent diagnostic removing that threshold returns **+0.81%**; this identifies a specification weakness without establishing executable capacity.

May–August is a **retrospective holdout**, with positions carried from April. The full-period funding summary had already been inspected, so no untouched out-of-sample claim is made. The nine specified combinations of 24/72/168-hour lookbacks and 1/1.5/2 cost buffers all lose money for the original combined rule: **−2.73% to −0.97%**.

With baseline positions fixed, doubling fees and raising execution costs to 10 bps changes returns to **+0.94% / −7.67%**. These diagnostics establish sensitivity to implementation choices. Daily candle-based drawdowns and ratios cannot validate intraday margin survival, simultaneous fills, token redemption or operational reliability.

**Figure 4.** Total-capital NAV and daily drawdown; shaded retrospective holdout.

**Figure 5.** Two-leg price PnL and funding reconciled to net PnL.

**Figure 6.** Net-return sensitivity to fees and execution costs, holding positions fixed.

---

# 作者工作说明：不纳入英文成稿字数

## 本节的证据等级

本节已完成可复算的“条件模型”，尚未完成可执行性核验。不要在简历、图注或投稿中将这些结果描述为真实账户业绩、经过成交验证的套利收益或无清算风险的回测。

| 证据等级 | 本节内容 |
|---|---|
| 已核实事实 | BTC、ETH 各 8,760 条研究期小时资金费；四个交易腿各 2,190 条研究期四小时 K 线；四小时聚合 OHLC 与此前日线完全一致，成交量在数值容差内一致。 |
| 模型估计 | 表中所有策略收益、净值、风险比率、费用与换手；使用明示的价格代理、费率、执行及资本假设。 |
| 观察推断 | 原规则的成交量门槛造成频繁退出，持有期不足以支持按 30 日摊销成本；这个结论针对本次规则组合。 |
| 待核验 | 历史 Oracle/Mark、同步双腿订单簿、历史费用及账户档位、有效保证金规则、真实成交和中断处理。 |

这份结果支持展示策略研究、损益归因、成本压力测试和对模型提出反对意见的能力。它不能替代基金经理访谈、基础设施审核、真实账户业绩核验或 SMA 监控记录。

## 三张图已完成，无需另去网站截图

- `outputs/Figure_04_NAV_Drawdown.png`：两种版本的全资本净值与日终回撤，最后四个月着色；另有 SVG。
- `outputs/Figure_05_Gross_to_Net.png`：价格损益、资金费、交易费、执行成本及融资/其他成本对账；另有 SVG。
- `outputs/Figure_06_Cost_Sensitivity.png`：交易费倍率与单腿单次执行成本矩阵；另有 SVG。

请保留每张图上的 **CONDITIONAL MODEL** 标签。图号承接此前章节，最终排版时可统一调整。

## 模型究竟做了什么

1. **币对映射。** BTC 永续对 UBTC/USDC（`@142`），ETH 永续对 UETH/USDC（`@151`）。当前映射快照保存在 inputs。名义上等单位对冲不消除 Unit 代币兑付及计价币风险。
2. **时点。** 00:00 的决策只使用此前已经结束的小时和前一日数据；04:00 先给旧仓位结算资金费，再按该四小时 K 线首笔成交价作为交易参考。参考价不是同步可成交报价，实际交易延迟与两腿成交时间差尚未建模。
3. **Oracle 代理。** 对每个小时，使用之前最近完整四小时现货 K 线的收盘价，而非使用未来收盘价。`fundingHistory.premium` 没有被误当成 Oracle 价格，资金费也没有再次除以 8。
4. **仓位。** 每日用交易参考时点的价格和扣费后总权益计算目标基础币数量，现货与永续数量相反、绝对值相等。20% 是各资产的单腿权重上限；两个资产总现货与总永续名义敞口各不超过 40%。较高的两腿参考价格决定数量，以使两腿都符合上限。
5. **资金。** 永续抵押独立记为总权益的 40%，现金缓冲至少 20%，不用现货重复抵押。内部划转按可即时完成、无额外费用处理。闲置资本不计息；初始资金已在交易场所内，所以没有本模型内的入金桥接流程。实际账户模式与可划转约束仍需核验。
6. **共同风险控制。** 以四小时永续成交价代理估算永续账户权益/永续名义敞口；低于 50% 时全部退出并停止交易。这不是交易所维持保证金规则，两种版本均未触发该模型控制，不构成“历史上不会清算”的证据。
7. **规则版本的滞回。** 空仓时要求 30 日资金费推算值超过成本门槛；持有后只要 72 小时均值仍为正且两个筛选条件满足即可续持，不要求每天重新超过入场门槛，也没有承诺固定持有 30 日。
8. **成交量筛选。** 分子是整个目标基础币仓位，分母是各腿前一 UTC 日的基础币成交量；分别检查两腿。它不是精确成交额或订单簿容量测算。被动基准没有该筛选，因此两版的差异包含资金费与风险筛选的共同影响，不能归因于资金费信号单一因素。
9. **期末。** 2026-08-31 23:00 的资金费结算后，使用当日最终收盘价参考平仓并收费；不计 2026-09-01 00:00 的资金费。末日平仓成本会影响最差日和期末回撤。
10. **费用与库存。** 按交易参考名义金额计算并以 USDC 等值扣费，没有同时修改成交价。实际 spot feeToken、手续费对基础币库存的影响、历史 szDecimals、最小订单和合约精度尚未还原；有真实 fills 时必须据此重新匹配两腿净数量。

## 费用口径与损益对账

当前示例是新独立账户、无其他交易量、无 staking/referral 折扣、全部 taker 的情景。模型最大 14 日加权交易量为被动约 17.4 万、规则约 59.2 万 USDC，低于当前 Tier-1 的 500 万门槛。加权交易量只用于确定档位：现货成交额 × 2 + 永续成交额；它不用于重复计算利润或手续费。

本次只能确认 2026-09-10 查询到的基础费率，不能证明其覆盖 2025-09 至 2026-08 的每一天。正式版本应建立包含 `effective_from_utc`、`effective_to_utc`、`market`、`maker_taker`、`fee_tier`、`staking/referral/quote modifiers`、`feeToken`、`evidence_url` 的有效日期表。当前 `userFees` 快照同样不能单独证明历史费率。

以匹配的单腿名义本金 N 计：往返交易费为 2 × (7 + 4.5) = 23 bps；两腿各买/卖一次的执行成本为 4 × 2 = 8 bps；合计 31 bps。门槛预算将两腿规范到共同名义金额，这是近似；实际模型手续费分别按各腿参考成交额计算。规则成本门槛为 1.5 × 31 = 46.5 bps，不是对十万美元总本金收取 46.5 bps。

| 全年损益，USDC | 被动 | 规则 |
|---|---:|---:|
| 现货价格损益 | −12,357.09 | −14,519.20 |
| 永续价格损益 | +12,373.71 | +14,656.62 |
| 两腿价格损益净额 | +16.61 | +137.43 |
| 资金费现金流代理估计 | +2,463.82 | +1,328.07 |
| 毛损益 | +2,480.44 | +1,465.49 |
| 交易手续费 | −411.97 | −2,442.26 |
| 额外执行成本 | −143.29 | −849.49 |
| 融资及其他费用（假设） | 0.00 | 0.00 |
| 净损益 | +1,925.18 | −1,826.25 |

表内展示四舍五入值，精确账本见 JSON。独立现金/库存账本与逐次估值账本核对，最终权益差小于 0.000001 USDC；入场前五个小时（00:00–04:00）仓位均为零，未领取入场前的资金费。

## 为什么规则版本亏损

原规则共有 BTC 25 次、ETH 26 次完整持仓区间，包括期末关闭的 BTC 仓位。排除期末强制平仓，50 次退出中，41 次由成交量门槛触发、9 次由非正资金费均值触发；本样本这两类退出没有重叠，也没有 100 bps 价差筛选导致的退出。

BTC 持仓区间的中位数为 4 日，ETH 为 2 日。用 30 日资金费去覆盖往返成本，而实际很快因另一个筛选条件退出，是本实现的主要弱点。

在看见原结果后，额外做了一次**机制诊断**：仅去除成交量筛选，保留资金费信号、价格筛选、资本和成本假设。全年估计收益变成 +0.81%，留出区间 +0.35%。这项事后分析没有被替换为正文的“最佳策略”，不应宣传为新发现的稳定 Alpha；它也没有证明被放宽的流动性条件可执行。详细结果在 `rule_diagnostics.json`。

## 参数、成本和留出区间

- 基准参数与 3×3 敏感性网格写入 `model_spec.json` 后才运行本次模型；此前已经看过全年的资金费描述统计，因此不宣称预注册或完全未见数据。
- 前段为 2025-09-01 至 2026-04-30，留出段为 2026-05-01 至 2026-08-31。连续运行，不在 5 月重新注入十万美元或重置已有仓位；留出收益从 4 月 30 日收盘总权益算起。分别包含 242 与 123 个日收益。
- 参数网格为回看 24/72/168 小时 × 成本缓冲 1/1.5/2。所有组合、留出结果均保留，不筛选最优值替代主规格。
- 成本矩阵固定基准仓位与毛现金流，仅改变费用。这是外生成本冲击诊断，不是假定从第一天就知道更高成本并据此重选信号的另一次策略优化。额外资金调拨及风险规则未在这些固定仓位压力情景中重新触发。
- 最大回撤恢复时间从谷底算到再次达到前高；被动为 19 日，若从前高到恢复则为 36 日。规则在截止日仍未恢复。最差周为滚动七个日历日的复合收益。
- `oracle_proxy_conditional_sensitivity.json` 提供一个可复算的条件误差界：**假如**各时点真实 Oracle 都在代理价 ±1% 内，资金费误差绝对值不超过逐小时资金费绝对额之和的 1%。1% 是情景假设，不是已观测误差区间。

## 正式实证还需要去哪里取数

| 缺口 | 优先来源 | 拿到数据后做什么 |
|---|---|---|
| 逐小时 Oracle、Mark | Hyperliquid 官方历史归档的 `asset_ctxs/YYYYMMDD.csv.lz4`；以实际文件字段和覆盖为准 | 匹配结算时点，替换 Oracle 代理；记录快照年龄。若归档快照不能准确对应结算，应保留误差标记。 |
| 双腿真实执行条件 | 官方历史 `market_data/.../l2Book`；分别核验 BTC/ETH 永续及 UBTC/UETH 现货覆盖 | 在相同时点按订单规模计算可执行 VWAP、价差、深度；不足深度不假定全额成交；计入撤单、部分成交和两腿延迟。 |
| 实际资金费与成交记录 | 有明确账户授权或公开可核验地址时，用官方账户历史 funding/fills 接口及完整归档 | 与期初仓位、外部转账和现金流水对账，保留 feeToken、费用、成交价与净库存；观察接口条数及历史保留限制。 |
| 当时有效费用 | 官方费率公告、可核验的当期费用记录与账户交易量 | 按 UTC 有效日期、14 日滚动交易量及真实可得折扣建模；不能把今日费率截图回填全年。 |
| 保证金与清算 | 官方当期 margin table、账户模式、Mark 轨迹、资金划转及异常事件 | 以事件顺序检查初始/维持保证金、缓冲耗尽和能否实际平仓；日线或四小时收盘没有触线不够。 |

官方历史归档可能延迟或缺失，并由请求者承担传输费用。此前匿名访问一个 asset_ctxs 文件及一个 BTC L2 文件返回 403；未因此认定文件不存在，也未绕过访问限制。[历史数据说明](https://hyperliquid.gitbook.io/hyperliquid-docs/historical-data)

可以先用你自己的 AWS 配置取一个样本文件核验格式，无需提供密钥：

```bash
aws s3 cp s3://hyperliquid-archive/asset_ctxs/20260831.csv.lz4 ./asset_ctxs_20260831.csv.lz4 --request-payer requester
```

这一个文件不足以完成一年回测。完整日期、字段、时点匹配与订单簿覆盖确认后，再替换模型输入并重新出三张图。

## Messari 在本节的位置

本节核心现金流以 Hyperliquid 官方数据为准，不需要 Dune。Messari 用于前后章节的市场结构与研究背景；HYPE 的聚合衍生品图不能替代 BTC/ETH 在 Hyperliquid 的资金费与订单簿，也没有现成截图能证明这两个自定义组合的净收益。三张策略图应由本节账本自行计算。

## 复现与文件

在已安装 numpy、pandas、matplotlib 的 Python 环境运行：

```bash
python3 build_section04.py
python3 diagnose_rule.py
```

第一条命令离线校验数据、重建两套账本、计算指标与敏感性并出图；第二条生成退出归因与单独标注的事后诊断。原始 API 响应、请求参数、资金费预热数据、模型规格和来源快照均已随包提供。`fetch_additional_inputs.py` 是本次四小时数据的只读抓取记录；重跑需要网络，且未来会受到 API 的最近 5,000 根 K 线保留限制，不能据此承诺永久在线回补同一历史区间。
