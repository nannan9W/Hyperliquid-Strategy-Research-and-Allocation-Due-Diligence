"""Post-result exit attribution and a clearly labelled diagnostic ablation.

This does not replace or optimize the pre-specified baseline. The ablation asks
whether the reported loss can be attributed to the funding filter alone.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import build_section04 as model

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
decisions = json.loads((OUT / "rule_decisions.json").read_text())
counts = {a: {"funding_nonpositive": 0, "volume_gate": 0, "price_gap_gate": 0,
              "total_nonterminal_exits": 0} for a in model.ASSETS}
previous = [False, False]
for row in decisions:
    for j, a in enumerate(model.ASSETS):
        if previous[j] and not row["active"][j]:
            counts[a]["total_nonterminal_exits"] += 1
            counts[a]["funding_nonpositive"] += int(row["mean_hourly_funding"][j] <= 0)
            counts[a]["volume_gate"] += int(not row["volume_gate"][j])
            counts[a]["price_gap_gate"] += int(row["prior_close_gap_bps"][j] >= 100)
    previous = row["active"]

trades = json.loads((OUT / "rule_trades.json").read_text())
durations = {a: [] for a in model.ASSETS}
entry = {}
for row in trades:
    a, t = row["asset"], pd.Timestamp(row["timestamp_utc"])
    if row["old_q"] <= 1e-12 < row["new_q"]:
        entry[a] = t
    if row["new_q"] <= 1e-12 < row["old_q"]:
        durations[a].append((t - entry.pop(a)).total_seconds() / 3600)

# A diagnostic relaxation in memory; the saved model_spec.json remains unchanged.
original_gate = model.SPEC["rule_max_position_prior_day_base_volume_fraction"]
model.SPEC["rule_max_position_prior_day_base_volume_fraction"] = 1e20
relaxed = model.simulate("rule")
model.SPEC["rule_max_position_prior_day_base_volume_fraction"] = original_gate
summary = model.describe(relaxed)
report = {
    "exit_causes_nonexclusive": counts,
    "holding_spells_hours": durations,
    "holding_spells_summary": {a: {"count": len(v), "median_days": np.median(v) / 24,
                                  "mean_days": np.mean(v) / 24, "maximum_days": max(v) / 24}
                               for a, v in durations.items()},
    "post_result_ablation": {
        "status": "Diagnostic selected after seeing the baseline result; not a new validated strategy or untouched OOS result",
        "change": "Remove the prior-day volume gate for both entry and exit; retain funding and price-gap filters, capital allocation and baseline costs",
        "performance": summary,
        "interpretation_limit": "This relaxes an implementation screen without proving any liquidity or capacity. It is a mechanism diagnostic, not an investability claim."
    }
}
model.save_json("rule_diagnostics.json", report)
print(json.dumps(model.plain({"exit_causes": counts, "holding_spells": report["holding_spells_summary"],
                              "ablation_full_return": summary["full_period"]["return"],
                              "ablation_holdout_return": summary["retrospective_holdout"]["return"]}), indent=2))
