"""Reproduce Figure 8 from explicit calendar assumptions, with no network access.

Requires Python 3.10+, matplotlib and an IANA time-zone database.
Run: python3 build_figure08.py

The figure contains no observed price series or simulated strategy returns.
All unavailable executable-spread values remain JSON null.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone, time
from pathlib import Path
from zoneinfo import ZoneInfo
import hashlib
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Rectangle, Patch, FancyBboxPatch

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)
SPEC = json.loads((ROOT / "schedule_spec.json").read_text())
UTC = timezone.utc
NY = ZoneInfo(SPEC["tsla_access"]["timezone"])
CHICAGO = ZoneInfo(SPEC["mgc_schedule"]["timezone"])
START = datetime.fromisoformat(SPEC["window_start_utc"].replace("Z", "+00:00"))
END = datetime.fromisoformat(SPEC["window_end_utc_exclusive"].replace("Z", "+00:00"))

NAVY = "#18334A"
TEAL = "#167F79"
TEAL_LIGHT = "#D9EEE9"
RUST = "#A65332"
RUST_LIGHT = "#F5E5DD"
GREY = "#657681"
GRID = "#E5EBEE"
BLUE_GREY = "#DCE5EB"


def utcstr(value):
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def dates_between(first, last):
    day = first
    while day <= last:
        yield day
        day += timedelta(days=1)


def local_dt(day, hhmm, zone):
    return datetime.combine(day, time.fromisoformat(hhmm), tzinfo=zone)


def tsla_open(t):
    z = t.astimezone(NY)
    day = z.date().isoformat()
    cfg = SPEC["tsla_access"]
    if z.weekday() >= 5 or day in cfg["full_day_closures_2026"]:
        return False
    close = cfg["early_closes_local_2026"].get(day, cfg["close_local"])
    return time.fromisoformat(cfg["open_local"]) <= z.time() < time.fromisoformat(close)


def mgc_open(t):
    z = t.astimezone(CHICAGO)
    wd, clock = z.weekday(), z.time()
    if wd == 5:  # Saturday
        return False
    if wd == 6:  # Sunday
        return clock >= time(17)
    if wd == 4:  # Friday
        return clock < time(16)
    return not (time(16) <= clock < time(17))


def boundaries():
    """Use exact localized event times, not a sampled hourly approximation."""
    points = {START, END}
    for day in dates_between((START - timedelta(days=2)).date(), END.date() + timedelta(days=2)):
        for hhmm in [SPEC["tsla_access"]["open_local"],
                     SPEC["tsla_access"]["early_closes_local_2026"].get(day.isoformat(), SPEC["tsla_access"]["close_local"])]:
            points.add(local_dt(day, hhmm, NY).astimezone(UTC))
        for hhmm in ["16:00", "17:00"]:
            points.add(local_dt(day, hhmm, CHICAGO).astimezone(UTC))
        points.add(local_dt(day, "00:00", UTC))
    return sorted(t for t in points if START <= t <= END)


def intervals(predicate, series):
    out = []
    points = boundaries()
    for a, b in zip(points[:-1], points[1:]):
        state = predicate(a + (b - a) / 2)
        if out and out[-1]["calendar_open"] == state:
            out[-1]["end"] = b
        else:
            out.append({"series": series, "start": a, "end": b, "calendar_open": state})
    return out


TSLA = intervals(tsla_open, "TSLA_shares_RTH_only")
MGC = intervals(mgc_open, "MGC_normal_schedule")


def serial(row):
    return {"series": row["series"], "start_utc": utcstr(row["start"]),
            "end_utc_exclusive": utcstr(row["end"]),
            "duration_hours": (row["end"] - row["start"]).total_seconds() / 3600,
            "calendar_open": row["calendar_open"]}


def write_data():
    closures = {}
    for name, rows in [("tsla", TSLA), ("mgc", MGC)]:
        closed = max((r for r in rows if not r["calendar_open"]), key=lambda r: r["end"] - r["start"])
        closures[name] = serial(closed)
    difference = (datetime.fromisoformat(closures["tsla"]["end_utc_exclusive"].replace("Z", "+00:00"))
                  - datetime.fromisoformat(closures["mgc"]["end_utc_exclusive"].replace("Z", "+00:00"))).total_seconds() / 3600
    summary = {"evidence_type": SPEC["evidence_type"], "tsla_weekend_gap_hours": closures["tsla"]["duration_hours"],
               "mgc_weekend_gap_hours": closures["mgc"]["duration_hours"],
               "reopening_difference_hours": difference, "weekend_closures": closures,
               "warning": "These are calendar/access durations, not observed hedge execution times."}
    save("calendar_summary.json", summary)
    save("schedule_intervals.json", [serial(r) for r in TSLA + MGC])
    evidence = []
    for rows in [TSLA, MGC]:
        for r in rows:
            evidence.append({**serial(r),
                             "paired_calendar_eligibility_conditional_on_HIP3_availability": r["calendar_open"],
                             "actual_paired_execution_verified": False,
                             "sell_perp_buy_hedge_entry_spread_bps": None,
                             "buy_perp_sell_hedge_entry_spread_bps": None,
                             "reason": "quote_and_contract_conversion_evidence_missing" if r["calendar_open"] else "external_hedge_closed_under_selected_calendar",
                             "quote_evidence_complete": False})
    save("spread_evidence_status.json", evidence)
    # Check meaningful boundaries: half-hour precision, DST, and CME daily break.
    assert summary["tsla_weekend_gap_hours"] == 65.5
    assert summary["mgc_weekend_gap_hours"] == 49.0
    assert summary["reopening_difference_hours"] == 15.5
    assert not mgc_open(datetime(2026, 8, 31, 21, 30, tzinfo=UTC))
    assert mgc_open(datetime(2026, 8, 31, 22, 0, tzinfo=UTC))
    assert all(r["sell_perp_buy_hedge_entry_spread_bps"] is None for r in evidence)
    for rows in [TSLA, MGC]:
        assert rows[0]["start"] == START and rows[-1]["end"] == END
        assert all(a["end"] == b["start"] for a, b in zip(rows[:-1], rows[1:]))
    save("validation.json", {"exact_event_boundaries": "passed", "daylight_saving_conversion": "passed",
                             "closed_gap_durations": "passed", "daily_maintenance": "passed",
                             "missing_spreads_remain_null": "passed", "historical_execution_verified": False})
    return summary


def x(t):
    return mdates.date2num(t)


def label_left(ax, y, title, subtitle):
    ax.text(-0.021, y + 0.11, title, transform=ax.get_yaxis_transform(), ha="right", va="center",
            fontsize=11, weight="bold", color=NAVY)
    ax.text(-0.021, y - 0.16, subtitle, transform=ax.get_yaxis_transform(), ha="right", va="center",
            fontsize=8.8, color=GREY)


def timeline(ax, rows, y, evidence=False):
    height = 0.53
    for r in rows:
        opened = r["calendar_open"]
        face = BLUE_GREY if evidence and opened else TEAL if opened else RUST_LIGHT
        edge = "#8096A6" if evidence and opened else face
        patch = Rectangle((x(r["start"]), y - height / 2), x(r["end"]) - x(r["start"]), height,
                          facecolor=face, edgecolor=edge, linewidth=0.5,
                          hatch="////" if evidence and opened else None, zorder=3)
        ax.add_patch(patch)
    closed = max((r for r in rows if not r["calendar_open"]), key=lambda r: r["end"] - r["start"])
    midpoint = closed["start"] + (closed["end"] - closed["start"]) / 2
    if evidence:
        text = "Hedge session closed | no paired execution"
        ax.text(x(midpoint), y, text, color=RUST, ha="center", va="center", fontsize=9.2, zorder=4)
    else:
        duration = (closed["end"] - closed["start"]).total_seconds() / 3600
        label = f"{duration:g} h without this hedge session"
        ax.text(x(midpoint), y + 0.01, label, color=RUST, ha="center", va="center", fontsize=11, weight="bold", zorder=4)


def axis_style(ax, bottom_labels=True):
    ax.set_xlim(x(START), x(END))
    ax.set_yticks([])
    for side in ["top", "left", "right"]:
        ax.spines[side].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ticks = [START + timedelta(hours=12 * i) for i in range(8)]
    ax.set_xticks([x(t) for t in ticks])
    ax.set_xticklabels([t.strftime("%a %d Aug\n%H:%M") if t.month == 8 else t.strftime("%a %d Sep\n%H:%M") for t in ticks], fontsize=8.7)
    ax.tick_params(axis="x", length=0, pad=8, colors=GREY, labelbottom=bottom_labels)
    for tick in ticks:
        ax.axvline(x(tick), color=GRID, linewidth=0.8, zorder=0)
    for a, b in [(datetime(2026, 8, 29, tzinfo=UTC), datetime(2026, 8, 31, tzinfo=UTC))]:
        ax.axvspan(x(a), x(b), color="#F8FAFB", zorder=-1)


def figure(summary):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                         "text.color": NAVY, "axes.labelcolor": NAVY,
                         "svg.fonttype": "none", "savefig.facecolor": "white"})
    fig = plt.figure(figsize=(18, 11.2), facecolor="white")
    fig.text(0.055, 0.957, "FIGURE 8  /  CROSS-ASSET RELATIVE VALUE", fontsize=10, color=TEAL, weight="bold")
    fig.text(0.055, 0.918, "HIP-3 weekend hedge availability", fontsize=26, weight="bold")
    fig.text(0.055, 0.887, "28–31 August 2026 · UTC · Published calendars and explicit access assumptions; no observed execution study", fontsize=11, color=GREY)

    cards = [
        ("65.5 h", "TSLA hedge-session gap", "Shares · regular-session-only access"),
        ("49 h", "Micro Gold hedge-session gap", "MGC · normal CME Globex schedule"),
        ("15.5 h", "Difference in reopening times", "MGC resumes before TSLA regular hours")
    ]
    for i, (number, title, detail) in enumerate(cards):
        left = 0.055 + i * 0.30
        fig.patches.append(FancyBboxPatch((left, 0.777), 0.281, 0.084, boxstyle="round,pad=0.007,rounding_size=0.008",
                                        transform=fig.transFigure, facecolor="#F3F7F8", edgecolor="none", zorder=-1))
        fig.text(left + 0.012, 0.817, number, fontsize=23, weight="bold", color=TEAL)
        fig.text(left + 0.11, 0.827, title, fontsize=10.4, weight="bold")
        fig.text(left + 0.012, 0.790, detail, fontsize=9.2, color=GREY)

    fig.text(0.055, 0.736, "A  |  Scheduled hedge access", fontsize=13, weight="bold")
    fig.text(0.945, 0.736, "Open calendar ≠ guaranteed fills", ha="right", fontsize=10, color=GREY)
    ax = fig.add_axes([0.215, 0.426, 0.73, 0.29])
    ax.set_ylim(-0.42, 3.65)
    axis_style(ax)
    y_hip, y_tsla, y_mgc = 2.88, 1.70, 0.52
    ax.add_patch(Rectangle((x(START), y_hip - 0.265), x(END) - x(START), 0.53,
                           facecolor=TEAL_LIGHT, edgecolor=TEAL, linewidth=1, linestyle=(0, (4, 3)), zorder=3))
    ax.text((x(START) + x(END)) / 2, y_hip, "24/7 trading design | historical market state not independently verified",
            fontsize=10.4, ha="center", va="center", color=TEAL, zorder=4)
    label_left(ax, y_hip, "HIP-3 TSLA / GOLD", "TradeXYZ · design only")
    label_left(ax, y_tsla, "TSLA shares", "Regular-session access")
    label_left(ax, y_mgc, "Micro Gold futures", "MGC · 10 troy oz / contract")
    timeline(ax, TSLA, y_tsla)
    timeline(ax, MGC, y_mgc)
    # Weekend gap endpoints and the two distinct reopening events.
    t_tsla_close = datetime(2026, 8, 28, 20, tzinfo=UTC)
    t_mgc_close = datetime(2026, 8, 28, 21, tzinfo=UTC)
    t_mgc_reopen = datetime(2026, 8, 30, 22, tzinfo=UTC)
    t_tsla_reopen = datetime(2026, 8, 31, 13, 30, tzinfo=UTC)
    for t, y, text in [(t_tsla_close, y_tsla, "Fri 20:00 close"), (t_mgc_close, y_mgc, "Fri 21:00 close")]:
        ax.text(x(t), y - 0.39, text, fontsize=8.5, ha="left", va="top", color=RUST)
    for t, y, text in [(t_mgc_reopen, y_mgc, "Sun 22:00 reopen"), (t_tsla_reopen, y_tsla, "Mon 13:30 reopen")]:
        ax.axvline(x(t), ymin=0.17, ymax=0.85, color=TEAL, linewidth=1, linestyle=(0, (2, 3)), zorder=2)
        ax.text(x(t), y + 0.38, text, fontsize=8.5, ha="center", va="bottom", color=TEAL, weight="bold")
    maint = datetime(2026, 8, 31, 21, 30, tzinfo=UTC)
    ax.annotate("Daily break\nMon 21:00–22:00", xy=(x(maint), y_mgc),
                xytext=(x(maint) - 0.23, -0.07), ha="right", va="top", fontsize=8.1, color=GREY,
                arrowprops={"arrowstyle": "-", "color": GREY, "lw": 0.7}, zorder=5)
    ax.legend(handles=[Patch(facecolor=TEAL, label="Scheduled hedge session open"),
                       Patch(facecolor=RUST_LIGHT, label="Closed under selected access calendar")],
              loc="upper left", bbox_to_anchor=(0, 1.055), ncol=2, frameon=False, fontsize=8.8, borderaxespad=0,
              handlelength=1.4, columnspacing=2.3)

    fig.text(0.055, 0.352, "B  |  Executable-spread evidence", fontsize=13, weight="bold")
    fig.text(0.055, 0.326, "Both spread series are unestimated: synchronized external quotes and verified HIP-3 contract conversion are missing.",
             fontsize=10.4, color=GREY)
    bx = fig.add_axes([0.215, 0.173, 0.73, 0.134])
    bx.set_ylim(-0.1, 1.88)
    axis_style(bx)
    timeline(bx, TSLA, 1.28, evidence=True)
    timeline(bx, MGC, 0.38, evidence=True)
    label_left(bx, 1.28, "TSLA pair", "Spread: N/A")
    label_left(bx, 0.38, "GOLD–MGC pair", "Spread: N/A")
    fig.legend(handles=[Patch(facecolor=RUST_LIGHT, label="Hedge session closed"),
                        Patch(facecolor=BLUE_GREY, edgecolor="#8096A6", hatch="////", label="Calendar permits quote matching; price evidence missing")],
               loc="lower left", bbox_to_anchor=(0.211, 0.083), ncol=2, frameon=False, fontsize=9,
               handlelength=1.6, columnspacing=2.3)
    fig.text(0.055, 0.072, "Scope: TSLA extended/overnight access is excluded by assumption. MGC uses its normal schedule; historical outages and broker restrictions are not audited.", fontsize=8.6, color=GREY)
    fig.text(0.055, 0.052, "No Friday-close forward fill, numerical spread curve or strategy return is presented. Nasdaq/CME calendars do not establish TradeXYZ oracle-session boundaries.", fontsize=8.6, color=GREY)
    fig.text(0.055, 0.028, "Sources: Nasdaq session hours + 2026 holiday calendar; CME Micro Metals; TradeXYZ docs. Checked 15 Sep 2026. Full URLs and assumptions accompany the figure.", fontsize=8.4, color=GREY)
    png, svg = OUT / "Figure_8_Hedge_Availability_Weekend.png", OUT / "Figure_8_Hedge_Availability_Weekend.svg"
    fig.savefig(png, dpi=220)
    fig.savefig(svg)
    plt.close(fig)
    save("artifact_manifest.json", {"files": [{"file": p.name, "bytes": p.stat().st_size,
                                                  "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in [png, svg]],
                                    "research_cutoff": SPEC["research_cutoff_utc"],
                                    "sources_checked": SPEC["sources_checked_utc_date"]})


if __name__ == "__main__":
    summary = write_data()
    figure(summary)
    print(json.dumps({k: v for k, v in summary.items() if k.endswith("hours")}, indent=2))
    print("Generated: outputs/Figure_8_Hedge_Availability_Weekend.png and .svg")
